import React from 'react';
import {Composition} from 'remotion';
import {ProductTest} from './ProductTest';
export const Root: React.FC = () => <Composition id="JiahaoShotcraftTest" component={ProductTest} width={1920} height={1080} fps={60} durationInFrames={600}/>;
