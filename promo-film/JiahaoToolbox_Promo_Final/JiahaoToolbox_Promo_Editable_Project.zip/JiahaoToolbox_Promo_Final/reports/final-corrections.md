# Final corrections

- Theme return at72–73s uses real themes source6.7–7.7s. The actual light-to-dark change occurs at source6.833s. Text and visible state agree after the physical toggle.
- One-second patch rendered from main frames4140–4199, then spliced without changing any timeline duration. The canonical editable timeline includes this correction for full rebuilds.
- JPEG-rendered full-range main video converted to limited-range yuv420p. Main is5220 frames,87.000s with60/1 frame rate and60000 track timescale. The approved intro video is stream copied separately.
- Decode-frame contact extraction disables filter reinitialization so a metadata boundary cannot reset the selection counter. Eighty final MP4 keyframes are reviewed.
- Black detection requires99.99% of pixels below1% luminance. A98% criterion falsely treats small white branding on black as an empty screen. Original intro is checked independently by180 decoded frame hashes.
- Exact cadence is enforced in the finishing script; an intermediate90.000033s mux was rejected by QA and rebuilt. No test is waived on that intermediate.

- Public delivery main segment uses libx264 CRF16 medium, B-frames2 and exact60fps timebase. This retains native dimensions while reducing the interim NVENC CQ16 file below GitHub individual-file limits. Final QA was rerun against the actual delivered file.
