import {Config} from '@remotion/cli/config';
Config.setVideoImageFormat('jpeg');
Config.setPixelFormat('yuv420p');
Config.setCodec('h264');
Config.setCrf(16);
Config.setScale(1);
Config.setConcurrency(6);
Config.setOverwriteOutput(true);
