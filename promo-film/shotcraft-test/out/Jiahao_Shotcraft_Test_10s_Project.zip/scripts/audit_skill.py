import hashlib,json,sys
from pathlib import Path
from urllib.parse import urlparse
root=Path(__file__).resolve().parents[1]
skill=Path.home()/'.codex/skills/video-shotcraft'
tree=json.loads((root/'review/repository-tree.json').read_text(encoding='utf-8'))['tree']
verified=0
for item in tree:
 if item['type']!='blob':continue
 p=skill/item['path'];assert p.is_file(),item['path'];data=p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['sha'],item['path']
 verified+=1
packages=[]
for p in skill.rglob('package.json'):
 if 'node_modules' in p.parts:continue
 d=json.loads(p.read_text(encoding='utf-8'));packages.append({'path':p.relative_to(skill).as_posix(),'scripts':d.get('scripts',{})})
hosts={}
for p in json.loads((root/'package-lock.json').read_text(encoding='utf-8'))['packages'].values():
 if p.get('resolved'):
  host=urlparse(p['resolved']).netloc;hosts[host]=hosts.get(host,0)+1
report={'repository':'https://github.com/Vincentwei1021/video-shotcraft','commit':'310330cadcf41f5d2b15ee1c908d629e26d0a324','destination':str(skill),'installedFilesMatchedGitTree':verified,
 'method':'Codex built-in skill-installer, pinned GitHub archive; root SKILL.md, compatible with official Codex skills-directory layout. No remote installer executed.',
 'metadata':{'name':'video-shotcraft','frontmatterValid':(skill/'SKILL.md').read_text(encoding='utf-8').startswith('---\nname: video-shotcraft\n')},
 'discovery':'Installed in user Codex skills directory. This turn reads the installed instructions and uses PageCam; automatic skill catalog refresh is expected next turn and has not been observed in this turn.',
 'npmInstall':'npm ci --ignore-scripts --no-audit --no-fund','dependencyDownloadHosts':hosts,'reviewedPackageScripts':packages,'executedRepositoryScripts':[],
 'browserDownload':'Remotion browser ensure -> Google chrome-for-testing-public chrome-headless-shell 149.0.7790.0/win64',
 'assets':[{'file':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in (root/'public').rglob('*') if p.is_file()]}
(root/'review/INSTALL_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'verifiedFiles':verified,'metadata':report['metadata'],'npmHosts':hosts},ensure_ascii=True))
