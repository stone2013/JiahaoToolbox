"""FFmpeg offline editor. Final mode refuses missing or unverified real captures."""
import argparse, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

ROOT=Path(__file__).resolve().parents[1]

def executable(name):
 candidates=list((ROOT/'tools/ffmpeg-compatible').rglob(name+'.exe'))
 if candidates:return str(candidates[0])
 found=shutil.which(name)
 if found:return found
 raise RuntimeError('Compatible FFmpeg is missing; see README. Use --ffmpeg/--ffprobe to supply another build.')

def probe(path,exe):
 return json.loads(subprocess.check_output([exe,'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path)],encoding='utf-8'))

def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def validate(m,mode,fp):
 if mode=='final':
  g=m['recordingGate']
  if not g.get('passed') or not all(g.get('criteria',{}).get(k) is True for k in ['noBlackFrames','mouseActionsVisible','startupComplete','resolution1080p','fps60','noObviousStutter']):
   raise ValueError('Formal export blocked: the complete 30-second real-operation test has not passed.')
  p=ROOT/(g.get('testFile') or '__MISSING_TEST__')
  if not p.is_file() or not g.get('sha256') or digest(p)!=g['sha256']:raise ValueError('30-second test evidence is missing or changed.')
  test=probe(p,fp)
  if float(test['format']['duration'])<29.95:raise ValueError('Test evidence is shorter than 30 seconds.')
 for s in m['timeline']:
  if s['id'] not in ('intro','outro') and mode=='final':
   if s.get('status')!='verified_real_capture' or not s.get('source'):raise ValueError('Missing verified real capture: '+s['id'])
  resource=s.get('source') if mode=='final' or s['id'] in ('intro','outro') else s.get('placeholder')
  p=(ROOT/resource).resolve()
  if not p.is_file():raise ValueError('Missing media: '+str(p))
  if mode=='final' and s['id'] not in ('intro','outro'):
   if not s.get('sha256') or digest(p)!=s['sha256']:raise ValueError('Capture checksum missing or changed: '+s['id'])
   meta=probe(p,fp);v=next(t for t in meta['streams'] if t['codec_type']=='video')
   n,d=map(int,v['avg_frame_rate'].split('/'))
   if (v['width'],v['height'])!=(1920,1080) or abs(n/d-60)>.01:raise ValueError('Capture must be native 1920x1080 60fps: '+s['id'])
   if float(meta['format']['duration'])+.02<s.get('trimIn',0)+s['duration']:raise ValueError('Capture is too short; no freeze-frame or looping allowed: '+s['id'])

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['storyboard','final'],default='storyboard');ap.add_argument('--encoder',choices=['h264_nvenc','libx264'],default='h264_nvenc');ap.add_argument('--ffmpeg');ap.add_argument('--ffprobe');ap.add_argument('--validate-only',action='store_true');args=ap.parse_args()
 ff=args.ffmpeg or executable('ffmpeg');fp=args.ffprobe or executable('ffprobe');m=json.loads((ROOT/'edit-manifest.json').read_text(encoding='utf-8'))
 validate(m,args.mode,fp)
 if args.validate_only:print('Manifest validation passed: '+args.mode);return
 build=ROOT/'build'/args.mode;build.mkdir(parents=True,exist_ok=True)
 report={'mode':args.mode,'encoder':args.encoder,'started':time.strftime('%Y-%m-%dT%H:%M:%S'),'operations':[]}
 enc=['-c:v','h264_nvenc','-preset','p5','-rc:v','vbr','-cq:v','18','-b:v','0','-profile:v','high','-bf','2','-g','120'] if args.encoder=='h264_nvenc' else ['-c:v','libx264','-preset','medium','-crf','18','-profile:v','high','-bf','2','-g','120']
 def run(command):
  report['operations'].append(command)
  result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding='utf-8',errors='replace')
  with (build/'ffmpeg.log').open('a',encoding='utf-8') as f:f.write('\n'+' '.join(command)+'\n'+result.stderr)
  if result.returncode:raise RuntimeError(result.stderr[-4000:])
 listing=[]
 for i,s in enumerate(m['timeline']):
  source=s.get('source') if args.mode=='final' or s['id'] in ('intro','outro') else s['placeholder']
  image=source.endswith('.png');dur=s['duration'];trim=s.get('trimIn',0) if args.mode=='final' else 0
  cmd=[ff,'-hide_banner','-loglevel','warning','-y']
  if image:cmd+=['-loop','1','-framerate','60']
  elif trim:cmd+=['-ss',str(trim)]
  cmd+=['-i',str(ROOT/source)]
  if s['id']!='intro':cmd+=['-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=48000']
  caption=args.mode=='final' and bool(s.get('captionAsset'))
  if caption:cmd+=['-loop','1','-framerate','60','-i',str(ROOT/s['captionAsset'])]
  vf='[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x081321,setsar=1,fps=60,setpts=PTS-STARTPTS'
  if caption:vf+='[base];[base][2:v]overlay=0:0:shortest=1'
  if s['id'] not in ('intro','startup'):vf+=f",fade=t=in:st=0:d={.3 if s['id']=='outro' else .15}"
  if s['id']!='intro':vf+=f",fade=t=out:st={dur-(.4 if s['id']=='outro' else .15)}:d={.4 if s['id']=='outro' else .15}"
  vf+=',format=yuv420p[v]'
  dest=build/f'{i:02d}_{s["id"]}.mp4'
  cmd+=['-filter_complex',vf,'-map','[v]','-map','0:a:0' if s['id']=='intro' else '1:a:0','-af',f'atrim=duration={dur},asetpts=PTS-STARTPTS','-frames:v',str(dur*60),'-t',str(dur),*enc,'-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-video_track_timescale','60000','-movflags','+faststart',str(dest)]
  run(cmd);listing.append(f"file '{dest.name}'\nduration {dur}\n")
 (build/'concat.txt').write_text(''.join(listing),encoding='utf-8')
 output=ROOT/'final'/('Jiahao_STORYBOARD_NOT_FINAL_1080p60.mp4' if args.mode=='storyboard' else 'JiahaoToolbox_Promo_1080p60.mp4')
 run([ff,'-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(build/'concat.txt'),'-map','0:v:0','-map','0:a:0','-c','copy','-t',str(m['duration']),'-movflags','+faststart',str(output)])
 meta=probe(output,fp);v=next(t for t in meta['streams'] if t['codec_type']=='video');frames=int(v.get('nb_read_frames',0))
 if frames!=m['duration']*60 or abs(float(meta['format']['duration'])-m['duration'])>.05:raise ValueError('Export duration/frame count failed validation; see build log.')
 report.update({'output':str(output),'sha256':digest(output),'probe':meta,'frameCount':frames,'expectedFrameCount':m['duration']*60,'formalCaptureGatePassed':m['recordingGate']['passed']})
 (ROOT/'reports'/f'export-{args.mode}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(output)

if __name__=='__main__':
 try:main()
 except Exception as e:print('EXPORT REFUSED / FAILED: '+str(e),file=sys.stderr);sys.exit(1)
