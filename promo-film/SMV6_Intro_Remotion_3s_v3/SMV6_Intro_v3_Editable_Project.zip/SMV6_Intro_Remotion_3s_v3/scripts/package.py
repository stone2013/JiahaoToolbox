from pathlib import Path
import zipfile,hashlib
p=Path(__file__).resolve().parents[1]
out=p/'out/SMV6_Intro_v3_Editable_Project.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in p.rglob('*'):
  if not f.is_file():continue
  rel=f.relative_to(p)
  if 'node_modules' in rel.parts or '.git' in rel.parts or f.suffix=='.zip' or f.name=='remotion-render.mp4':continue
  z.write(f,Path(p.name)/rel)
print(out.name,out.stat().st_size)
