"""Offline editorial preparation. Does not control or record the Windows desktop."""
import argparse, hashlib, json, shutil, subprocess, textwrap, uuid
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
FPS = 60
FONT = Path('C:/Windows/Fonts/msyh.ttc')
BOLD = Path('C:/Windows/Fonts/msyhbd.ttc')
SHOTS = [
 ('startup', 5, '完整启动动画', '从 Logo 到主仪表盘', '从原生窗口出现前开始录制；完整保留 Logo、文字和进入仪表盘过渡。'),
 ('themes', 8, '深浅主题切换', '深浅主题，随手切换', '同一总览页面：深色停留 → 鼠标点击浅色 → 停留 → 切回深色。'),
 ('monitor', 12, '实时硬件监控', 'CPU · GPU · 内存 · 磁盘 · 网络', '总览真实采样曲线 → CPU → GPU → 内存/网络；保留实际读数和采样时间。'),
 ('pinyin', 10, '拼音快速搜索', '输入拼音，快速定位功能', '在搜索框依次输入 xitong、xtgj；显示真实结果，点击“系统工具”完成导航。'),
 ('tools', 9, '常用系统工具', '常用 Windows 工具，集中打开', '展示工具分类；打开任务管理器，切到性能页。外部窗口需单独配置 OBS 窗口捕获。'),
 ('diagnostics', 9, '系统诊断', '逐项查看系统检测结果', '真实运行一次只读诊断，展示完成状态和结果；不剪改异常结论，不操作修复/安全设置。'),
]

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def font(n,bold=False): return ImageFont.truetype(str(BOLD if bold else FONT),n)

def bg():
 im=Image.new('RGB',(1920,1080));d=ImageDraw.Draw(im)
 for y in range(1080):
  t=y/1080;d.line((0,y,1920,y),fill=(int(8+3*t),int(19+8*t),int(33+12*t)))
 d.line((120,160,1800,160),fill='#203852',width=2)
 return im

def cube(im,x,y,s=5):
 # Original toolbox SVG paths; vector geometry is preserved, no software UI is fabricated.
 shape=[(24,1),(45,13),(45,39),(24,51),(3,39),(3,13)]
 right=[(24,25),(45,13),(45,39),(24,51)]
 def grad(poly,c1,c2,diagonal=False):
  size=(48*s,52*s);mask=Image.new('L',size);ImageDraw.Draw(mask).polygon([(int(a*s),int(b*s)) for a,b in poly],fill=255)
  layer=Image.new('RGB',size);px=layer.load()
  for yy in range(size[1]):
   for xx in range(size[0]):
    t=((xx/size[0]+yy/size[1])/2) if diagonal else yy/size[1]
    px[xx,yy]=tuple(round(a+(b-a)*t) for a,b in zip(c1,c2))
  im.paste(layer,(x,y),mask)
 grad(shape,(48,196,255),(20,112,236),True);grad(right,(23,141,245),(7,82,193))
 d=ImageDraw.Draw(im)
 for p in [[(24,8),(37,15),(24,23),(11,15)],[(12,22),(20,27),(20,43),(16,41),(16,30),(12,28)],[(28,29),(37,24),(37,29),(32,32),(32,41),(28,43)]]:
  d.polygon([(x+a*s,y+b*s) for a,b in p],fill='#eaf9ff')

def xml_escape(s):
 import html
 return html.escape(s,quote=True)

def save_card(shot,number,start):
 sid,duration,title,caption,action=shot
 im=bg();d=ImageDraw.Draw(im)
 d.text((120,75),'嘉豪工具箱 · 实录宣传片分镜',font=font(30),fill='#8db6e4')
 d.rounded_rectangle((120,230,540,300),radius=12,fill='#463d1c')
 d.text((142,240),'待录制 · 非软件画面',font=font(32,True),fill='#ffd37a')
 d.text((120,355),f'{number:02d}  {title}',font=font(76,True),fill='#f3f8ff')
 d.text((125,475),caption,font=font(39),fill='#83c8ff')
 # Explicit planning text, deliberately not a mock software interface.
 lines=textwrap.wrap(action,40)
 for i,line in enumerate(lines):d.text((125,600+58*i),line,font=font(32),fill='#afc4dc')
 d.text((125,930),f'计划 {start:02d}–{start+duration:02d} 秒   |   本镜头需要真实软件录制',font=font(29),fill='#829bb7')
 im.save(ROOT/f'assets/cards/{sid}.png')
 svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#081321"/><g font-family="Microsoft YaHei"><text x="120" y="120" fill="#8db6e4" font-size="30">嘉豪工具箱 · 实录宣传片分镜</text><text x="120" y="285" fill="#ffd37a" font-size="36">待录制 · 非软件画面</text><text x="120" y="420" fill="#f3f8ff" font-size="76" font-weight="bold">{number:02d} {xml_escape(title)}</text><text x="120" y="525" fill="#83c8ff" font-size="39">{xml_escape(caption)}</text>{''.join(f'<text x="120" y="{645+58*i}" fill="#afc4dc" font-size="32">{xml_escape(line)}</text>' for i,line in enumerate(lines))}<text x="120" y="975" fill="#829bb7" font-size="29">计划 {start}–{start+duration} 秒 · 必须补充真实录屏</text></g></svg>'''
 (ROOT/f'assets/cards/{sid}.svg').write_text(svg,encoding='utf-8')

def captions(sid,text):
 im=Image.new('RGBA',(1920,1080));d=ImageDraw.Draw(im)
 d.rounded_rectangle((110,920,1810,1015),radius=14,fill=(5,14,26,224))
 d.rectangle((110,920,116,1015),fill='#32b9ff')
 d.text((155,935),text,font=font(39,True),fill='#f3f8ff');im.save(ROOT/f'assets/captions/{sid}.png')
 (ROOT/f'assets/captions/{sid}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080"><rect x="110" y="920" width="1700" height="95" rx="14" fill="#050e1a" fill-opacity=".88"/><rect x="110" y="920" width="6" height="95" fill="#32b9ff"/><text x="155" y="980" font-family="Microsoft YaHei" font-weight="bold" font-size="39" fill="#f3f8ff">{xml_escape(text)}</text></svg>',encoding='utf-8')

def outro():
 im=bg();d=ImageDraw.Draw(im);cube(im,390,325,5)
 d.text((730,340),'嘉豪工具箱',font=font(94,True),fill='#f3f8ff')
 d.text((738,465),'JIAHAO TOOLBOX',font=font(37),fill='#83c8ff')
 d.text((742,530),'v4.4.0',font=font(31),fill='#9cb4cd')
 d.text((560,760),'让常用功能触手可及',font=font(47),fill='#d8e8fa')
 d.text((545,890),'github.com/stone2013/JiahaoToolbox',font=font(32),fill='#8db6e4')
 im.save(ROOT/'assets/outro.png')
 logo=(ROOT/'assets/logo-original.svg').read_text(encoding='utf-8').replace('<svg ','<svg x="390" y="325" width="240" height="260" ',1)
 (ROOT/'assets/outro.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080"><rect width="1920" height="1080" fill="#081321"/>{logo}<g font-family="Microsoft YaHei"><text x="730" y="440" font-size="94" font-weight="bold" fill="#f3f8ff">嘉豪工具箱</text><text x="738" y="510" font-size="37" fill="#83c8ff">JIAHAO TOOLBOX</text><text x="742" y="570" font-size="31" fill="#9cb4cd">v4.4.0</text><text x="560" y="815" font-size="47" fill="#d8e8fa">让常用功能触手可及</text><text x="545" y="940" font-size="32" fill="#8db6e4">github.com/stone2013/JiahaoToolbox</text></g></svg>',encoding='utf-8')

def prop(el,name,value):ET.SubElement(el,'property',name=name).text=str(value)

def project(manifest):
 complete=all(s.get('status')=='verified_real_capture' for s in manifest['timeline'] if s['id'] not in ('intro','outro'))
 tree=ET.parse(ROOT/'test/kdenlive-official-template.kdenlive');mlt=tree.getroot()
 mlt.set('root',str(ROOT/'project').replace('\\','/'));mlt.set('producer','main_bin')
 profile=mlt.find('profile');profile.set('frame_rate_num','60');profile.set('description','HD 1080p 60 fps')
 main=mlt.find("playlist[@id='main_bin']")
 for e in list(main):
  if e.tag=='entry':main.remove(e)
  elif e.get('name')=='kdenlive:docproperties.groups':e.text='[]'
  elif e.get('name')=='kdenlive:docproperties.profile':e.text='atsc_1080p_60'
  elif e.get('name')=='kdenlive:docproperties.zoneout':e.text='3660'
  elif e.get('name')=='kdenlive:documentnotes':e.text=('真实录屏剪辑工程。所有功能画面来自实际 OBS 捕获；片头原素材与片尾图形独立。' if complete else '分镜工程：黄色“待录制”卡不是软件画面。')+'字幕在独立 V2 轨道；工程未通过 Kdenlive GUI 打开验证。FFmpeg 成片转场以脚本为准。'
 for p in list(mlt):
  if p.tag in ('producer','chain') and p.get('id')!='black_track':mlt.remove(p)
 for playlist in mlt.findall('playlist'):
  if playlist is main:continue
  for e in list(playlist):
   if e.tag in ('entry','blank'):playlist.remove(e)
 total=manifest['duration']*FPS;bin_id=2
 def producer(pid,resource,frames,name,is_image=False,bin_entry=True,kind='base',k_id=None):
  nonlocal bin_id
  p=ET.Element('producer',id=pid,**{'in':'0','out':str(frames-1)})
  prop(p,'resource',str((ROOT/resource).resolve()).replace('\\','/'));prop(p,'mlt_service','qimage' if is_image else 'avformat')
  prop(p,'length',frames);prop(p,'eof','pause');prop(p,'kdenlive:clipname',name);prop(p,'kdenlive:folderid',-1)
  if k_id is None:k_id=bin_id;bin_id+=1
  prop(p,'kdenlive:id',k_id)
  if is_image:prop(p,'kdenlive:clip_type',2);prop(p,'ttl',frames);prop(p,'set.test_audio',1)
  else:
   prop(p,'audio_index',-1 if kind=='video' else 1);prop(p,'video_index',-1 if kind=='audio' else 0)
   prop(p,'set.test_audio',1 if kind=='video' else 0);prop(p,'set.test_image',1 if kind=='audio' else 0)
  mlt.insert(list(mlt).index(main),p)
  if bin_entry:ET.SubElement(main,'entry',producer=pid,**{'in':'0','out':str(frames-1)})
  return k_id
 v=mlt.find("playlist[@id='playlist4']");a=mlt.find("playlist[@id='playlist2']");overlay=mlt.find("playlist[@id='playlist6']")
 for i,s in enumerate(manifest['timeline']):
  frames=s['duration']*FPS;res=s.get('source') or s.get('placeholder');is_image=res.endswith('.png');offset=round(s.get('trimIn',0)*FPS) if not is_image else 0
  kid=producer(f'bin_{i}',res,frames+offset,s['title'],is_image)
  producer(f'video_{i}',res,frames+offset,s['title'],is_image,False,'video',kid)
  ET.SubElement(v,'entry',producer=f'video_{i}',**{'in':str(offset),'out':str(offset+frames-1)})
  if s['id']=='intro':
   producer('intro_audio',res,frames,'SMV6 原始片头音频',False,False,'audio',kid);ET.SubElement(a,'entry',producer='intro_audio',**{'in':'0','out':str(frames-1)})
  else:ET.SubElement(a,'blank',length=str(frames))
  if s.get('captionAsset'):
   producer(f'caption_{i}',s['captionAsset'],frames,'字幕图层 · '+s['caption'],True)
   ET.SubElement(overlay,'entry',producer=f'caption_{i}',**{'in':'0','out':str(frames-1)})
  else:ET.SubElement(overlay,'blank',length=str(frames))
 review=ROOT/'reports/media-review.json'
 ref_frames=int(json.loads(review.read_text(encoding='utf-8'))[0]['probe']['streams'][0]['nb_read_frames']) if review.exists() else 175
 producer('qa_reference','media/reference/Preflight_REAL_NOT_APPROVED_FOR_PROMO.mp4',ref_frames,'QA 预检参考 · 非正式演示素材')
 for tid,name in [('tractor0','A2 备用配音'),('tractor1','A1 SMV6 原音'),('tractor2','V1 片头 / 真实录屏 / 品牌片尾' if complete else 'V1 待录制分镜'),('tractor3','V2 可替换字幕图层')]:
  t=mlt.find(f"tractor[@id='{tid}']");t.set('out',str(total-1));prop(t,'kdenlive:track_name',name)
 mlt.find("producer[@id='black_track']").set('out',str(total-1))
 mlt.find("tractor[@id='tractor4']").set('out',str(total-1))
 ET.indent(tree,space='  ');stem='JiahaoToolbox_PROMO_EDITABLE' if complete else 'JiahaoToolbox_STORYBOARD_EDITABLE';dest=ROOT/f'project/{stem}.kdenlive';tree.write(dest,encoding='utf-8',xml_declaration=True)
 # Interchange MLT uses the same graph, with the final tractor as playback producer.
 mlt.set('producer','tractor4');tree.write(ROOT/f'project/{stem}.mlt',encoding='utf-8',xml_declaration=True)
 ids={e.get('id') for e in mlt if e.get('id')}
 for e in mlt.iter():
  if e.get('producer') and e.get('producer') not in ids:raise ValueError('Unresolved MLT producer '+e.get('producer'))
 for e in mlt.findall(".//property[@name='resource']"):
  if e.text not in ('black',) and not Path(e.text).exists():raise ValueError('Missing project asset '+e.text)
 (ROOT/'reports/project-validation.json').write_text(json.dumps({'xmlParsed':True,'referencesResolved':True,'profile':'1920x1080 60p','durationSeconds':61,'kdenliveGUIValidated':False,'formatVersion':'1.04; newer Kdenlive can migrate legacy projects','reference':'KDE/kdenlive tests/dataset/av.kdenlive'},ensure_ascii=False,indent=2),encoding='utf-8')

def main():
 for p in ['assets/cards','assets/captions','project','subtitles','reports','build','final']: (ROOT/p).mkdir(parents=True,exist_ok=True)
 outro();timeline=[{'id':'intro','title':'SMV6 三秒片头（原素材）','duration':3,'source':'media/intro/SMV6_Intro_v2_3s.mp4','status':'provided','start':0}];start=3
 for i,shot in enumerate(SHOTS,1):
  sid,dur,title,caption,action=shot;save_card(shot,i,start);captions(sid,caption)
  timeline.append({'id':sid,'title':title,'duration':dur,'start':start,'source':None,'expectedCapture':f'media/capture/{i:02d}_{sid}.mkv','trimIn':0,'status':'pending_recording','placeholder':f'assets/cards/{sid}.png','caption':caption,'captionAsset':f'assets/captions/{sid}.png','action':action});start+=dur
 timeline.append({'id':'outro','title':'品牌片尾（图形设计）','duration':5,'start':start,'source':'assets/outro.png','status':'graphic_design'})
 mf=ROOT/'edit-manifest.json'
 if mf.exists():
  old=json.loads(mf.read_text(encoding='utf-8'))
  for s in timeline:
   prior=next((p for p in old.get('timeline',[]) if p['id']==s['id']),{})
   if prior.get('status')=='verified_real_capture':s.update({k:prior[k] for k in ['source','trimIn','status','sha256','action'] if k in prior})
  gate=old.get('recordingGate')
 else:gate=None
 manifest={'project':'嘉豪工具箱真实操作宣传片','fps':60,'width':1920,'height':1080,'duration':61,'recordingGate':gate or {'passed':False,'testFile':None,'sha256':None,'criteria':{'noBlackFrames':False,'mouseActionsVisible':False,'startupComplete':False,'resolution1080p':False,'fps60':False,'noObviousStutter':False}},'timeline':timeline,'audioPolicy':'保留原 SMV6 三秒片头音频；其他段落静音。未提供授权 BGM 或配音。','transitions':'片头完整 3 秒，硬切进入启动；功能段内 0.15 秒淡入/淡出，片尾 0.3/0.4 秒；不改变镜头计划时长。'}
 mf.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 def stamp(t):return f'{t//3600:02d}:{t//60%60:02d}:{t%60:02d},000'
 subs=[]
 for s in timeline:
  if not s.get('caption'):continue
  subs.append(f"{len(subs)+1}\n{stamp(s['start'])} --> {stamp(s['start']+s['duration'])}\n{s['caption']}\n")
 (ROOT/'subtitles/zh-CN.srt').write_text('\n'.join(subs),encoding='utf-8')
 (ROOT/'subtitles/narration-draft.txt').write_text('\n'.join(s['caption'] for s in timeline if s.get('caption'))+'\n嘉豪工具箱，让常用功能触手可及。\n',encoding='utf-8')
 project(manifest)
 inventory=[]
 for p in sorted((ROOT/'media').rglob('*')):
  if p.is_file():inventory.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'role':'provided_intro' if 'intro' in p.parts else ('real_capture' if 'capture' in p.parts else 'qa_reference_only')})
 (ROOT/'reports/media-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Prepared 61-second editorial plan, graphics, captions, manifest and XML projects. GUI validation not performed.')

if __name__=='__main__':main()
