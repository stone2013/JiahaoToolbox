import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const local=path.resolve(root,'../promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin');
const ff=process.env.FFMPEG_PATH || (fs.existsSync(path.join(local,'ffmpeg.exe'))?path.join(local,'ffmpeg.exe'):'ffmpeg');
const fp=process.env.FFPROBE_PATH || (fs.existsSync(path.join(local,'ffprobe.exe'))?path.join(local,'ffprobe.exe'):'ffprobe');
const file=path.join(root,'out/Jiahao_Shotcraft_Test_10s_1080p60.mp4');
const probe=JSON.parse(execFileSync(fp,['-v','error','-count_frames','-show_streams','-show_format','-of','json',file],{encoding:'utf8'}));
const v=probe.streams.find(s=>s.codec_type==='video');
if(v.width!==1920 || v.height!==1080 || v.avg_frame_rate!=='60/1' || +v.nb_read_frames!==600 || Math.abs(+probe.format.duration-10)>.05)throw Error('Native 1080p60 / 600-frame validation failed.');
execFileSync(ff,['-hide_banner','-v','error','-i',file,'-f','null','-'],{stdio:['ignore','pipe','pipe']});
for(const frame of [90,180,210,240,300,360,450,479,480,510,540,599]){
 execFileSync(ff,['-v','error','-y','-ss',String(frame/60),'-i',file,'-frames:v','1',path.join(root,`out/qa/video-f${frame}.png`)]);
}
const asset=path.join(root,'public/textures/cpu-real.png');
// Conservative perspective magnification bound, over all motion keys:
// 1920px layout at zoom<=.70; rotations <=12/2 deg; perspective 5000.
// Treat both rotated axes at their largest simultaneously to overestimate.
const depth=960*Math.sin(12*Math.PI/180)+540*Math.sin(2*Math.PI/180);
const maxScale=.70*5000/(5000-depth);
const effectiveScale=maxScale*1920/1850;
if(effectiveScale>=1)throw Error('Screenshot enlargement exceeds original capture pixels.');
const report={passed:true,probe,decodeErrors:[],nativeComposition:{width:1920,height:1080,fps:60,frames:600,renderScale:1},
 screenshot:{file:'public/textures/cpu-real.png',sha256:crypto.createHash('sha256').update(fs.readFileSync(asset)).digest('hex'),textureWidth:1920,textureHeight:1080,originalWindowPixels:[1850,1040],maxConservativePixelScaleAgainstOriginal:effectiveScale,noEnlargement:effectiveScale<1,disclosure:'Actual CPU page snapshot from existing OBS footage, 2026-10-17 15:03:19; numbers and curve are unchanged. Not live monitoring.'},
 sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),
 visualReview:'Pending independent review. Keyframes extracted at full 1920x1080.',
 audio:'Only the original SMV6 intro audio; no additional BGM or SFX.',
 tools:{node:process.version,ffmpeg:execFileSync(ff,['-version'],{encoding:'utf8'}).split('\n')[0],ffprobe:execFileSync(fp,['-version'],{encoding:'utf8'}).split('\n')[0]}};
fs.writeFileSync(path.join(root,'out/ffprobe.json'),JSON.stringify(probe,null,2));
const reviewFile=path.join(root,'out/INDEPENDENT_REVIEW.json');
if(fs.existsSync(reviewFile)){
 const review=JSON.parse(fs.readFileSync(reviewFile,'utf8'));
 if(review.sha256===report.sha256){report.visualReview='Independent keyframe and source review completed; see INDEPENDENT_REVIEW.md for scope and limitations.';report.independentReview=review;}
}
fs.writeFileSync(path.join(root,'out/TEST_REPORT.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({passed:report.passed,resolution:[v.width,v.height],fps:v.avg_frame_rate,frames:v.nb_read_frames,duration:probe.format.duration,maxScreenshotScale:effectiveScale},null,2));
