from pathlib import Path
import json,subprocess,os,shutil
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parents[3];ROOT=P.parent;FALLBACK=ROOT/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe';FF=Path(os.environ.get('FFMPEG_PATH') or (str(FALLBACK) if FALLBACK.exists() else (shutil.which('ffmpeg') or 'ffmpeg')));V=P/'JiahaoToolbox_Promo_Final_1080p60.mp4';D=P/'reports/final-frames';D.mkdir(exist_ok=True)
shots=json.loads((P/'project/remotion/src/timeline.json').read_text(encoding='utf-8'));frames={0,35,100,179,250,3850,4100,4330,4690,5200,5380}
for s in shots:
 frames.add(round((s['start']+min(1,s['duration']*.45))*60));frames.add(round((s['start']+s['duration'])*60)-6)
frames.update([2760+169+8,2760+284+8,2760+451+8,3403,3818]);frames=sorted(frames)
flt='select='+ '+'.join(f'eq(n\\,{f})' for f in frames)
for old in D.glob('selected-*.jpg'): old.unlink()
subprocess.run([str(FF),'-v','error','-y','-reinit_filter','0','-i',str(V),'-vf',flt,'-fps_mode','vfr','-q:v','2',str(D/'selected-%03d.jpg')],check=True)
files=sorted(D.glob('selected-*.jpg'));assert len(files)==len(frames),(len(files),len(frames))
for file,f in zip(files,frames):file.replace(D/f'f{f:04}.jpg')
for page in range((len(frames)+15)//16):
 section=frames[page*16:page*16+16];sheet=Image.new('RGB',(1280,820),'#081321');dr=ImageDraw.Draw(sheet)
 for i,f in enumerate(section):
  im=Image.open(D/f'f{f:04}.jpg');im.thumbnail((320,180));x=i%4*320;y=i//4*205;sheet.paste(im,(x,y));dr.text((x+5,y+183),f'{f/60:.2f}s / f{f}',fill='white')
 sheet.save(P/f'reports/final-contact-{page+1}.jpg',quality=94)
(P/'reports/final-frame-index.json').write_text(json.dumps({'origin':'Actual decoded final MP4 frames, not previews','frames':frames},indent=2),encoding='utf-8')
subprocess.run([str(FF),'-v','error','-y','-ss','4.25','-i',str(V),'-frames:v','1',str(P/'Bilibili_Cover.png')],check=True)
print(len(frames),'actual encoded keyframes extracted; publication cover generated')
