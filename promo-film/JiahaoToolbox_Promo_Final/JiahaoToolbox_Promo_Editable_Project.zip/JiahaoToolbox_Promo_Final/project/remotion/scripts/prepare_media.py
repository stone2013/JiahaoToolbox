from pathlib import Path
import subprocess,json,hashlib,shutil,sys
ROOT=Path(__file__).resolve().parents[4];P=ROOT/'JiahaoToolbox_Promo_Final';FF=ROOT/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe'
PUB=P/'project/remotion/public/media';PUB.mkdir(parents=True,exist_ok=True)
RAW=ROOT/'promo-film/raw'
# Native capture pixels are preserved; only trimming, privacy masks and encoding are applied.
FRESH=[(565,236,220,28),(1440,460,310,30)]
OLD=[(510,278,240,36),(1515,550,365,45)]
entries=[
 ('overview',RAW/'Jiahao_2026-10-17_16-44-43.mkv',24,32,FRESH),
 ('cpu',RAW/'Jiahao_2026-10-17_16-44-43.mkv',1,5,[]),
 ('gpu',RAW/'Jiahao_2026-10-17_16-44-43.mkv',6,3.5,[]),
 ('memory',RAW/'Jiahao_2026-10-17_16-44-43.mkv',10,3.5,[]),
 ('disk',RAW/'Jiahao_2026-10-17_16-44-43.mkv',14,3.5,[]),
 ('network',RAW/'Jiahao_2026-10-17_16-44-43.mkv',18,3.5,[(655,714,300,35)]),
 ('search',RAW/'Jiahao_2026-10-17_16-46-11.mkv',0,10,FRESH),
 ('tool-click',RAW/'Jiahao_2026-10-17_16-46-11.mkv',10,3,[]),
 ('taskmgr',RAW/'Jiahao_2026-10-17_16-42-21.mkv',2,4,[(640,180,282,890)]),
 ('info-launch',RAW/'Jiahao_2026-10-17_16-50-51.mkv',1,4,[]),
 ('msinfo',RAW/'Jiahao_2026-10-17_16-43-34.mkv',2,4,[(833,208,540,28),(833,657,540,29)]),
 ('themes',ROOT/'promo-film/media/capture/02_themes.mp4',0,8,OLD),
 ('diagnostics',ROOT/'promo-film/media/capture/06_diagnostics.mp4',0,9,[]),
 ('startup',ROOT/'promo-film/media/capture/01_startup.mp4',0,5,OLD),
]
rows=[];raw_private=P/'recordings/raw-private';raw_private.mkdir(exist_ok=True)
for name,src,start,duration,masks in entries:
 if len(sys.argv)>1 and name!=sys.argv[1]:continue
 dst=PUB/(name+'.mp4');vf=['setsar=1', 'setpts=PTS-STARTPTS']+[f'drawbox=x={x}:y={y}:w={w}:h={h}:color=0x162436:t=fill'+(":enable='gte(t,1.2)'" if name=='startup' else '') for x,y,w,h in masks]
 subprocess.run([str(FF),'-v','error','-y','-ss',str(start),'-i',str(src),'-an','-vf',','.join(vf),'-frames:v',str(round(duration*60)),'-r','60','-c:v','h264_nvenc','-preset','p5','-cq','16','-b:v','0','-pix_fmt','yuv420p',str(dst)],check=True)
 h=hashlib.sha256(src.read_bytes()).hexdigest();rows.append({'id':name,'source':str(src.relative_to(ROOT)),'sourceSHA256':h,'inSeconds':start,'durationSeconds':duration,'speed':1,'privacyMasks':masks,'output':f'project/remotion/public/media/{dst.name}'})
 if not (raw_private/src.name).exists():shutil.copy2(src,raw_private/src.name)
 print('Conformed',name,flush=True)
shutil.copy2(P/'assets/logo.svg',P/'project/remotion/public/logo.svg')
from PIL import Image
Image.new('RGBA',(1,1),(0,0,0,0)).save(P/'project/remotion/public/transparent.png')

if len(sys.argv)>1:
 old=json.loads((P/'reports/capture-provenance.json').read_text(encoding='utf-8'));rows=[x for x in old if x['id']!=sys.argv[1]]+rows
(P/'reports/capture-provenance.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('All conformed clips contain real frames at normal speed.')
