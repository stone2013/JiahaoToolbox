import React from 'react';
import {AbsoluteFill,Composition,registerRoot,Sequence,OffthreadVideo,Img,staticFile,useCurrentFrame,interpolate,Easing,Audio} from 'remotion';
import {PageCam} from './lib/PageCam';
import timeline from './timeline.json';
const E=Easing.bezier(.22,1,.36,1);
const k=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:E});
const focuses:Record<string,[number,number,number,number]>={cpu:[400,325,335,172],memory:[735,325,335,172],disk:[1070,325,335,172],network:[1428,325,335,172],chart:[410,510,890,285]};
type Shot=typeof timeline[number];
const Scene:React.FC<{shot:Shot}>=({shot:s})=>{
 const f=useCurrentFrame(),d=Math.round(s.duration*60),enter=k(f,0,22);
 const target=focuses[s.view];
 const focused=Boolean(target);
 const displayTitle=s.clip==='search'?(f<164?'智能拼音搜索':f<284?'xitong · 系统相关功能':f<451?'xtgj · 系统工具':'rwglq · 任务管理器'):s.title;
 const cx=target?target[0]+target[2]/2:960;
 const cy=target?target[1]+target[3]/2:540;
 const keys=s.view==='search'?[{frame:0,cx:960,cy:540,zoom:.94},{frame:75,cx:960,cy:540,zoom:.94},{frame:145,cx:960,cy:420,zoom:1},{frame:d-1,cx:960,cy:420,zoom:1}]:[
 {frame:0,cx:focused?cx-24:960,cy:focused?cy+30:540,zoom:focused?.94:.91},
 {frame:d-1,cx,cy,zoom:focused?1:.97}];
 return <AbsoluteFill style={{background:'linear-gradient(135deg,#081321,#0e2038)',overflow:'hidden',fontFamily:'"Microsoft YaHei", "Segoe UI", sans-serif',color:'#fff'}}>
  <div style={{position:'absolute',inset:0,opacity:s.view==='hero'?.28:s.view==='outro'?.17:1}}>
   <PageCam src="transparent.png" pageH={1080} keys={keys}>
    <OffthreadVideo muted src={staticFile('media/'+s.clip+'.mp4')} startFrom={Math.round(s.sourceIn*60)} style={{position:'absolute',left:0,top:0,width:1920,height:1080}}/>
    {target&&<div style={{position:'absolute',left:target[0]-5,top:target[1]-5,width:target[2]+10,height:target[3]+10,border:'2px solid #479bff',borderRadius:18,boxShadow:'0 0 0 2500px rgba(3,10,20,.48)',boxSizing:'border-box'}}/>}
   </PageCam>
  </div>
  {s.view==='hero'?<div style={{position:'absolute',left:140,top:320,transform:`translateY(${24*(1-enter)}px)`,opacity:enter}}>
   <Img src={staticFile('logo.svg')} style={{width:116,height:126,marginBottom:30}}/>
   <div style={{fontSize:108,fontWeight:700,letterSpacing:1,lineHeight:1.25}}>嘉豪工具箱</div>
   <div style={{fontSize:43,color:'#c5d9ef',marginTop:32}}>{s.subtitle}</div>
  </div>:s.view==='outro'?<AbsoluteFill style={{alignItems:'center',justifyContent:'center',opacity:enter,transform:`scale(${.98+.02*enter})`}}>
   <Img src={staticFile('logo.svg')} style={{width:112,height:122,marginBottom:30}}/>
   <div style={{fontSize:92,fontWeight:700}}>嘉豪工具箱</div>
   <div style={{fontSize:44,letterSpacing:7,color:'#c7d7e8',marginTop:22}}>JIAHAO TOOLBOX</div>
   <div style={{height:2,width:400*enter,background:'#398ff5',marginTop:42}}/>
   <div style={{fontSize:45,color:'#a6bfd9',marginTop:34}}>Made by SMV6</div>
  </AbsoluteFill>:<>
   <div style={{position:'absolute',left:0,right:0,bottom:0,height:250,background:'linear-gradient(transparent,rgba(3,10,20,.97))'}}/>
   <div style={{position:'absolute',left:76,bottom:52,opacity:enter,transform:`translateY(${14*(1-enter)}px)`}}>
    <div style={{fontSize:80,fontWeight:700,lineHeight:1.35,textShadow:'0 2px 8px #030a14'}}>{displayTitle}</div>
    <div style={{fontSize:45,color:'#c4d8ee',marginTop:12,lineHeight:1.3}}>{s.subtitle}</div>
   </div>
  </>}
  {/* A restrained 12-frame wipe accent; underlying recorded action remains visible. */}
  {f<12&&s.start>3&&<div style={{position:'absolute',top:0,bottom:0,width:70,left:-70+(2060*k(f,0,11)),background:'linear-gradient(90deg,transparent,rgba(62,146,255,.30),transparent)'}}/>}
  <div style={{position:'absolute',left:0,bottom:0,height:3,width:1920*((s.start-3)*60+f)/5220,background:'#398ff5'}}/>
 </AbsoluteFill>;
};
export const Promo:React.FC<{bgm?:boolean}>=({bgm=true})=> <AbsoluteFill>
 {timeline.map(s=><Sequence key={s.start} from={Math.round((s.start-3)*60)} durationInFrames={Math.round(s.duration*60)}><Scene shot={s}/></Sequence>)}
 <Sequence durationInFrames={5220}><Audio src={staticFile(bgm?'audio/master-main.wav':'audio/master-sfx-only.wav')}/></Sequence>
</AbsoluteFill>;
export const FullPromo:React.FC<{bgm?:boolean}>=({bgm=true})=><AbsoluteFill>
 <Sequence durationInFrames={180}><OffthreadVideo muted src={staticFile('media/SMV6_Intro_v3_1080p60.mp4')}/><Audio src={staticFile('media/SMV6_Intro_v3_1080p60.mp4')}/></Sequence>
 <Sequence from={180} durationInFrames={5220}><Promo bgm={bgm}/></Sequence>
</AbsoluteFill>;
registerRoot(()=> <>
 <Composition id="JiahaoPromo" component={Promo} defaultProps={{bgm:true}} durationInFrames={5220} fps={60} width={1920} height={1080}/>
 <Composition id="JiahaoPromoFull" component={FullPromo} defaultProps={{bgm:true}} durationInFrames={5400} fps={60} width={1920} height={1080}/>
</>);
