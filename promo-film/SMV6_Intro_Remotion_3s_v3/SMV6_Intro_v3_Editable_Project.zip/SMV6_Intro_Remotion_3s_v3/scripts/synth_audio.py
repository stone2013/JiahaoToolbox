# Original deterministic SMV6 audio. Python standard library only; 48kHz stereo PCM.
import wave, math, struct
from pathlib import Path
RATE=48000
out=Path(__file__).resolve().parents[1]/'public/audio/smv6-soft-electronic.wav'
def voice(t,start,freq,amp,decay):
 x=t-start
 if x<0:return 0.0
 attack=(1-math.exp(-x/0.09))**2
 tail=math.exp(-x/decay)
 return amp*attack*tail*(math.sin(2*math.pi*freq*x+0.18*math.sin(2*math.pi*freq*0.5*x))+0.16*math.sin(2*math.pi*freq*2*x))
with wave.open(str(out),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(RATE)
 frames=bytearray()
 for i in range(3*RATE):
  t=i/RATE
  v=voice(t,.08,130.8128,.095,.85)+voice(t,.52,261.6256,.07,.65)+voice(t,1.02,391.9954,.045,.55)
  fade=min(1,max(0,(2.9-t)/.35))
  v=max(-1,min(1,v*fade))
  frames.extend(struct.pack('<hh',int(v*32767),int(v*32767)))
 w.writeframes(frames)
print(out.name)

