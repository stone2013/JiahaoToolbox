"""Share only editorial assets; never include OBS credentials, tools or personal settings."""
import hashlib,json,zipfile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.stdout.reconfigure(encoding='utf-8')
files=[]
for folder in ['assets','media','subtitles']:
 files += [p for p in (ROOT/folder).rglob('*') if p.is_file()]
files += list((ROOT/'reports').glob('*.png'))
for name in ['README.md','STORYBOARD.md','RECORDING_TEST_REPORT.md','edit-manifest.json','requirements.txt',
             'scripts/prepare_edit.py','scripts/render_promo.py','scripts/review_media.py','scripts/build_real_segments.py','scripts/package_editing_kit.py','scripts/check_final.py',
             'test/kdenlive-official-template.kdenlive','project/JiahaoToolbox_PROMO_EDITABLE.kdenlive','project/JiahaoToolbox_PROMO_EDITABLE.mlt','final/JiahaoToolbox_Promo_1080p60.mp4',
             'reports/recording-test-30s.json','reports/test30-v3-obs-stats.json','reports/real-capture-provenance.json',
             'reports/export-final.json','reports/project-validation.json','reports/final-qa.json']:
 files.append(ROOT/name)
provenance=json.loads((ROOT/'reports/real-capture-provenance.json').read_text(encoding='utf-8'))
files += [ROOT/s['rawFile'] for p in provenance for s in p['sourceRanges']]
files=sorted(set(files))
assert all(p.is_file() for p in files),[str(p) for p in files if not p.is_file()]
inventory=[]
for p in files:
 with p.open('rb') as f:checksum=hashlib.file_digest(f,'sha256').hexdigest()
 inventory.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':checksum})
(ROOT/'reports/delivery-checksums.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf-8')
files.append(ROOT/'reports/delivery-checksums.json')
target=ROOT/'final/JiahaoToolbox_Promo_Editing_Kit.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=2) as z:
 for p in files:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert not any(n.startswith(('private/','tools/','.venv/','app/')) for n in z.namelist())
print(target)
