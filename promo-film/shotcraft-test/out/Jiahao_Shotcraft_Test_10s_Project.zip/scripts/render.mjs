import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const raw=path.join(root,'out/remotion-render.mp4');
if(!process.argv.includes('--finish-only'))execFileSync(process.execPath,[path.join(root,'node_modules/@remotion/cli/remotion-cli.js'),'render','src/index.ts','JiahaoShotcraftTest',raw],{cwd:root,stdio:'inherit'});
const local=path.resolve(root,'../promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe');
const ff=process.env.FFMPEG_PATH || (fs.existsSync(local)?local:'ffmpeg');
// Preserve all 600 Remotion-rendered video frames without resampling or re-encoding.
// Trim AAC tail padding to exactly ten seconds; actual intro audio is in the first three seconds.
execFileSync(ff,['-hide_banner','-loglevel','error','-y','-i',raw,'-map','0:v:0','-map','0:a:0','-c:v','copy','-af','atrim=duration=10,asetpts=PTS-STARTPTS','-c:a','aac','-b:a','192k','-t','10','-movflags','+faststart',path.join(root,'out/Jiahao_Shotcraft_Test_10s_1080p60.mp4')],{stdio:'inherit'});
console.log('Native Remotion frames preserved; final MP4 audio trimmed to 10 seconds.');
