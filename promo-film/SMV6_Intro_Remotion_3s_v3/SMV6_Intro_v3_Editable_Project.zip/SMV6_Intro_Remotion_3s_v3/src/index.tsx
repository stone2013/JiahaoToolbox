import React from 'react';
import {registerRoot,Composition,AbsoluteFill,Audio,Sequence,staticFile,useCurrentFrame,interpolate,Easing} from 'remotion';
const ease=Easing.bezier(0.22,1,0.36,1);
const progress=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{easing:ease,extrapolateLeft:'clamp',extrapolateRight:'clamp'});
export const SMV6Intro:React.FC=()=>{
 const f=useCurrentFrame(), title=progress(f,5,53),line=progress(f,31,83),tag=progress(f,61,99);
 return <AbsoluteFill style={{background:'#000',color:'#fff',fontFamily:'Arial, Helvetica, sans-serif'}}>
  <div style={{position:'absolute',left:0,right:0,top:367,height:220,display:'flex',alignItems:'center',justifyContent:'center',opacity:title,transform:`scale(${0.955+0.045*title})`}}>
   <div style={{fontSize:184,fontWeight:700,letterSpacing:15,lineHeight:1,paddingLeft:15}}>SMV6</div>
  </div>
  <div style={{position:'absolute',left:690,top:607,width:540,height:2,background:'#398ff5',transform:`scaleX(${line})`,transformOrigin:'center',opacity:progress(f,31,43)}}/>
  <div style={{position:'absolute',top:650,left:0,right:0,textAlign:'center',fontSize:45,fontWeight:400,letterSpacing:3,paddingLeft:3,lineHeight:1.4,opacity:tag,transform:`translateY(${5*(1-tag)}px)`}}>CREATE BEYOND LIMITS</div>
  <Sequence durationInFrames={180}><Audio src={staticFile('audio/smv6-soft-electronic.wav')}/></Sequence>
 </AbsoluteFill>;
};
registerRoot(()=> <Composition id="SMV6Intro" component={SMV6Intro} durationInFrames={180} fps={60} width={1920} height={1080}/>);



