# 真实录屏
原始OBS文件保存在raw-private，仅本地保存。包含用户标识的原片不进入公开ZIP。脱敏、正常速度的编辑片段位于../project/remotion/public/media。完整逐段原片SHA256、时间范围和遮挡坐标见../reports/capture-provenance.json。录制使用OBS窗口捕获，不包括通知/其他桌面窗口；外部工具单独选择实际窗口捕获，剪辑保留真实启动入口及真实运行结果。
