import json,subprocess,xml.etree.ElementTree as ET
from render_promo import ROOT, executable,probe,digest
ff,fp=executable('ffmpeg'),executable('ffprobe')
p=ROOT/'final/JiahaoToolbox_Promo_1080p60.mp4'
m=probe(p,fp);v=next(s for s in m['streams'] if s['codec_type']=='video')
assert (v['width'],v['height'],v['avg_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'60/1',3660)
assert abs(float(m['format']['duration'])-61)<.05
dec=subprocess.run([ff,'-v','error','-i',str(p),'-f','null','-'],capture_output=True,text=True)
assert dec.returncode==0 and not dec.stderr.strip(),dec.stderr
for name,offset in [('first-half',0),('second-half',30)]:
 subprocess.run([ff,'-v','error','-y','-ss',str(offset),'-i',str(p),'-t','30','-vf','fps=1/2,scale=480:270,tile=5x3','-frames:v','1',str(ROOT/f'reports/final-{name}.png')],check=True)
frames=subprocess.check_output([ff,'-v','error','-ss','16.3','-i',str(p),'-t','1','-an','-vf','crop=1000:400:400:400','-f','framemd5','-'],encoding='utf-8')
hashes=[line.split(',')[-1].strip() for line in frames.splitlines() if line and not line.startswith('#')]
longest=run=1
for a,b in zip(hashes,hashes[1:]):
 run=run+1 if a==b else 1;longest=max(longest,run)
report={'output':str(p.relative_to(ROOT)),'sha256':digest(p),'width':1920,'height':1080,'fps':'60/1','durationSeconds':float(m['format']['duration']),'decodedVideoFrames':int(v['nb_read_frames']),'fullDecodeExitCode':dec.returncode,'decodeErrors':dec.stderr,
        'cpuChartROI1Second':{'decodedFrames':len(hashes),'distinctHashes':len(set(hashes)),'longestIdenticalFrameRun':longest,'limitation':'Only a one-second CPU-page region; not a global UI performance benchmark.'},
        'contactSheets':['reports/final-first-half.png','reports/final-second-half.png'],
        'visualReview':'Pending manual contact-sheet inspection; update after reviewing actual generated PNGs.',
        'audio':'Original intro audio retained, other segments intentionally silent. No speaker listening test.',
        'limitations':['Kdenlive GUI load was not tested.','Task Manager footage shows the actual process page, not performance page.','Native source window fitted proportionally to output; no synthetic UI footage.']}
root=ET.parse(ROOT/'project/JiahaoToolbox_PROMO_EDITABLE.kdenlive').getroot()
playlist=next(x for x in root.findall('playlist') if x.get('id')=='playlist4')
entries=playlist.findall('entry');total=sum(int(x.get('out'))-int(x.get('in'))+1 for x in entries)
profile=root.find('profile')
assert total==3660 and len(entries)==8
assert (profile.get('width'),profile.get('height'),profile.get('frame_rate_num'))==('1920','1080','60')
report['editableProject']={'xmlVideoEntries':len(entries),'timelineFrames':total,'profile':'1920x1080 60p','guiValidated':False}
(ROOT/'reports/final-qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
