"""Conform selected, actually recorded OBS ranges. No generated software frames."""
import argparse,json, subprocess
from pathlib import Path
from render_promo import ROOT, executable, digest, probe

ff, fp = executable('ffmpeg'), executable('ffprobe')
ap=argparse.ArgumentParser();ap.add_argument('--only');args=ap.parse_args()
test = ROOT/'media/reference/Recording_Test_30s_1080p60.mp4'
meta = probe(test, fp)
v = next(s for s in meta['streams'] if s['codec_type']=='video')
assert (v['width'],v['height'],v['avg_frame_rate'],int(v['nb_read_frames'])) == (1920,1080,'60/1',1800)
decoded = subprocess.run([ff,'-v','error','-i',str(test),'-f','null','-'],capture_output=True,text=True)
assert decoded.returncode == 0 and not decoded.stderr.strip(), decoded.stderr
black = subprocess.run([ff,'-hide_banner','-i',str(test),'-vf','blackdetect=d=0.05:pix_th=0.01:pic_th=0.98','-an','-f','null','-'],capture_output=True,text=True)
intervals = [s for s in black.stderr.splitlines() if 'black_start' in s]
assert not intervals, intervals
stats = json.loads((ROOT/'reports/test30-v3-obs-stats.json').read_text())
end = stats['samples'][-1]['stats']; before = stats['before']
report = {'testFile':str(test.relative_to(ROOT)), 'sha256':digest(test),'duration':meta['format']['duration'],
          'width':1920,'height':1080,'fps':60,'decodedFrames':1800,'decodeErrors':decoded.stderr,
          'pureBlackIntervals':intervals,'renderSkippedFramesDelta':end['renderSkippedFrames']-before['renderSkippedFrames'],
          'encodingSkippedFrames':end['outputSkippedFrames'],
          'maxOBSRenderMs':max(s['stats']['averageFrameRenderTime'] for s in stats['samples']),
          'maxOBSCPUPercent':max(s['stats']['cpuUsage'] for s in stats['samples']),
          'visualReview':'Sequential startup frames show native background, cube, brand and dashboard transition. Two-second contact sheet shows live curves and dark/light/dark changes. Actual mouse actions were performed through Windows input and cursor capture was enabled.',
          'limitations':'1080p60 is recorded output. Native window was 1850x1040, fitted proportionally. Does not prove every app animation frame is 60fps. Pure-black threshold excludes intentional dark blue startup background. One render and one encoder delayed frame occurred in the 40-second source; no sustained capture stall was observed.'}
(ROOT/'reports/recording-test-30s.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
manifest = json.loads((ROOT/'edit-manifest.json').read_text(encoding='utf-8'))
manifest['recordingGate'] = {'passed':True,'testFile':str(test.relative_to(ROOT)).replace('\\','/'),'sha256':digest(test),
                           'criteria':{k:True for k in manifest['recordingGate']['criteria']},'report':'reports/recording-test-30s.json'}
# In/out seconds are measured against the raw OBS recording, at normal speed.
test_raw='Jiahao_2026-10-17_14-59-57.mkv'
main_raw='Jiahao_2026-10-17_15-03-18.mkv'
selections={
 'startup':[(test_raw,1,5)],
 'themes':[(test_raw,21.5,8)],
 'monitor':[(main_raw,0.5,3),(main_raw,7,3),(main_raw,26,2),(main_raw,34,2),(main_raw,43,2)],
 'pinyin':[(main_raw,65,4),(main_raw,81,6)],
 'tools':[(main_raw,93,4),('Jiahao_2026-10-17_15-05-13.mkv',2,5)],
 'diagnostics':[('Jiahao_2026-10-17_15-05-38.mkv',2,9)],
}
work=ROOT/'build/real-selection';work.mkdir(parents=True,exist_ok=True)
provenance_path=ROOT/'reports/real-capture-provenance.json'
provenance=json.loads(provenance_path.read_text(encoding='utf-8')) if provenance_path.exists() else []
source_metadata={}
for shot in manifest['timeline']:
 if shot['id'] not in selections:continue
 if args.only and shot['id']!=args.only:continue
 sid=shot['id'];parts=[];sources=[]
 assert sum(d for _,_,d in selections[sid])==shot['duration']
 for i,(name,start,duration) in enumerate(selections[sid]):
  src=ROOT/'raw'/name;dest=work/f'{sid}-{i}.mp4'
  if name not in source_metadata:
   source_metadata[name]=json.loads(subprocess.check_output([fp,'-v','error','-show_format','-of','json',str(src)],encoding='utf-8'))
  source_meta=source_metadata[name]
  assert float(source_meta['format']['duration']) >= start+duration
  subprocess.run([ff,'-hide_banner','-loglevel','error','-y','-ss',str(start),'-i',str(src),'-an',
                  '-vf','setsar=1,fps=60,setpts=PTS-STARTPTS','-r','60','-fps_mode','cfr','-frames:v',str(int(duration*60)),'-t',str(duration),
                  '-c:v','h264_nvenc','-preset','p5','-cq','18','-b:v','0','-pix_fmt','yuv420p',
                  '-video_track_timescale','60000',str(dest)],check=True)
  parts.append(dest)
  sources.append({'rawFile':str(src.relative_to(ROOT)).replace('\\','/'),'sha256':digest(src),'startSeconds':start,'durationSeconds':duration})
 listing=work/f'{sid}.txt';listing.write_text(''.join(f"file '{p.name}'\nduration {selection[2]}\n" for p,selection in zip(parts,selections[sid])),encoding='utf-8')
 target=ROOT/shot['expectedCapture'].replace('.mkv','.mp4')
 subprocess.run([ff,'-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(target)],check=True)
 actual=probe(target,fp); video=next(s for s in actual['streams'] if s['codec_type']=='video')
 assert int(video['nb_read_frames']) == shot['duration']*60
 shot.update(source=str(target.relative_to(ROOT)).replace('\\','/'),trimIn=0,status='verified_real_capture',sha256=digest(target))
 if sid=='tools':shot['action']='实录系统工具页并点击任务管理器；切到实际打开的任务管理器进程页。当前自动化未能切到性能页，未伪造该操作。'
 provenance=[p for p in provenance if p['id']!=sid]
 provenance.append({'id':sid,'output':shot['source'],'sourceRanges':sources})
(ROOT/'edit-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'reports/real-capture-provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
print('Real ranges conformed. Capture provenance and 30-second QA evidence saved.')
