# SMV6 Intro v3
Editable native Remotion project. Node.js 22+ recommended.

```sh
npm ci --ignore-scripts
npm run dev
npm run typecheck
python scripts/synth_audio.py
npm run render
```
Entry: src/index.tsx. Composition: SMV6Intro, 1920x1080, 60 fps, 180 frames. Edit text, timing, easing and layout directly in TSX. Audio source: scripts/synth_audio.py; output WAV included. FFmpeg must be on PATH or FFMPEG_PATH set; Remotion downloads its browser on a fresh machine if necessary. Arial uses the installed system font (not redistributed); install Arial for matching typography. H.264 CRF16, yuv420p, native scale1. Render script copies rendered video without scaling and trims AAC tail to exactly3s.
Final output: out/SMV6_Intro_v3_1080p60.mp4. No third-party footage or generated hardware data. No modifications to old SMV6 projects.
