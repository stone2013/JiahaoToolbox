from pathlib import Path
import subprocess,json,os,shutil
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parents[1]; b=p.parent/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin'; ff=os.environ.get('FFMPEG_PATH') or (str(b/'ffmpeg.exe') if b.exists() else 'ffmpeg');probe=os.environ.get('FFPROBE_PATH') or (str(b/'ffprobe.exe') if b.exists() else 'ffprobe')
v=p/'out/SMV6_Intro_v3_1080p60.mp4'
j=json.loads(subprocess.check_output([probe,'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(v)],text=True));(p/'out/ffprobe.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
s=next(x for x in j['streams'] if x['codec_type']=='video');assert(s['width'],s['height'],s['avg_frame_rate'],s['nb_read_frames'])==(1920,1080,'60/1','180');assert float(j['format']['duration'])==3.0;assert s['codec_name']=='h264'
subprocess.run([ff,'-v','error','-i',str(v),'-f','null','-'],check=True)
frames=[0,20,45,70,100,150,179]; sheet=Image.new('RGB',(960,4*300),(20,20,20));d=ImageDraw.Draw(sheet)
for n,f in enumerate(frames):
 out=p/f'out/f{f:03}.png';subprocess.run([ff,'-v','error','-y','-i',str(v),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(out)],check=True)
 im=Image.open(out);im.thumbnail((480,270));x=n%2*480;y=n//2*300;sheet.paste(im,(x,y));d.text((x+8,y+274),f'Frame {f}',fill='white')
sheet.save(p/'out/contact-sheet.jpg')
a=subprocess.run([ff,'-hide_banner','-i',str(v),'-af','volumedetect','-vn','-f','null','-'],capture_output=True,text=True);(p/'out/audio-analysis.txt').write_text(a.stderr,encoding='utf-8')
print('PASS: H264,1920x1080,60fps,180 frames,3.000s; full decode passed')
