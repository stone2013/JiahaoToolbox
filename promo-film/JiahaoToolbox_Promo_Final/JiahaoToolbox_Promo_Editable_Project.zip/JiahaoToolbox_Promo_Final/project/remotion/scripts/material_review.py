from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
r=Path.cwd();p=r/'JiahaoToolbox_Promo_Final';ff=r/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe'
cases={'main-fresh':('16-44-43',[2,5,8,12,16,20,24,32,45,55]),'search-fresh':('16-46-11',[1,3,4.5,6,7,8.5,10,11.5]),'tools-click':('16-40-25',[48,54,60,67,78,95,108]),'taskmgr':('16-42-21',[2,12,25]),'msinfo':('16-43-34',[2,5,12]),'precheck':('16-39-47',[0,5,10,20,30,35])}
for name,(key,times) in cases.items():
 files=list((r/'promo-film/raw').glob('*'+key+'.mkv'))
 if not files:continue
 src=files[0];sheet=Image.new('RGB',(960,((len(times)+2)//3)*205),'#101827');d=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  out=p/f'private/{name}-{i}.png';c=subprocess.run([str(ff),'-v','error','-y','-ss',str(t),'-i',str(src),'-frames:v','1',str(out)],capture_output=True)
  if out.exists():
   im=Image.open(out);im.thumbnail((320,180));x=i%3*320;y=i//3*205;sheet.paste(im,(x,y));d.text((x+6,y+183),str(t)+'s',fill='white')
 sheet.save(p/f'private/{name}-contact.jpg')
print('Material contact sheets generated')
