from pathlib import Path
import json,hashlib,zipfile
P=Path(__file__).resolve().parents[3]
Z=P/'JiahaoToolbox_Promo_Editable_Project.zip'
# Allow-list public delivery. Original uncensored recordings and machine config never enter.
files=[]
for directory in ['project/remotion/src','project/remotion/public','assets']:
 files.extend(f for f in (P/directory).rglob('*') if f.is_file())
files.extend(f for f in (P/'project/remotion').glob('*') if f.is_file())
files.extend(f for f in (P/'project/remotion/scripts').glob('*') if f.is_file() and f.suffix in ['.py','.mjs'])
for name in ['original-bgm-120bpm.wav','original-sfx.wav','AUDIO_LICENSE.md','SFX_CUES.json']:
 files.append(P/'audio'/name)
for name in ['README.md','storyboard.md','TEST_REPORT.md','BILIBILI_DESCRIPTION.txt','Bilibili_Cover.png','recordings/README.md']:
 files.append(P/name)
for pattern in ['*.json','*.md','blackdetect.txt','silencedetect.txt','final-contact-*.jpg','final-frames/*.jpg','independent/*.json','independent/*.jpg','independent/contact.jpg']:
 files.extend(f for f in (P/'reports').glob(pattern) if f.is_file())
files=sorted(set(files))
assert all(f.exists() for f in files)
assert not any('node_modules' in f.parts or 'raw-private' in f.parts or 'private' in f.parts for f in files)
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,str(Path('JiahaoToolbox_Promo_Final')/f.relative_to(P)))
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 names=z.namelist()
 assert any(n.endswith('/public/media/search.mp4') for n in names)
 assert any(n.endswith('/package-lock.json') for n in names)
 assert any(n.endswith('/audio/original-bgm-120bpm.wav') for n in names)
assert Z.stat().st_size<95*1024*1024,Z.stat().st_size
items=[P/'JiahaoToolbox_Promo_Final_1080p60.mp4',P/'JiahaoToolbox_Promo_SFX_Only_1080p60.mp4',Z,P/'Bilibili_Cover.png']
(P/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in items),encoding='utf-8')
print(json.dumps({'archiveBytes':Z.stat().st_size,'publicFiles':len(files),'zipCRC':'passed','privateRawExcluded':True}))
