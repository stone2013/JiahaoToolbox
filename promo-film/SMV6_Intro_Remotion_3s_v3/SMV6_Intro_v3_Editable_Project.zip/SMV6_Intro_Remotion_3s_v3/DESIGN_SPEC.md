# SMV6 minimal studio intro — custom single brand shot
Native 1920x1080, 60fps, 180 frames. Black #000; white SMV6, blue #398ff5 2px rule. System Arial bold/regular, no raster/video input. No rotation, particles, glow or overshoot.
Timeline: f0-4 black; f5-53 wordmark opacity + scale .955→1; f31-83 center-out 540px line; f61-99 tagline opacity + 5px settling; f99-179 settled hold (1.35s). Easing cubic-bezier(.22,1,.36,1).
User specified all brand content and minimal style. Custom animation, not a Gallery reproduction. Studied Gallery logo-shrink-wordmark-lockup and exact demo for brand lockup/settled hold only; its neon/rotation/overshoot are outside this brief and not implemented. Gallery visual matching is not claimed.
Audio: original deterministic soft electronic C3/C4/G4 layered tones, explicit user request. No background music or UI sound effects. Smooth envelopes, full fade before 2.9s. Synthesis source included.
No software UI, hardware data, footage, private files, or low-resolution upscaling. Existing SMV6 projects unchanged.

Final tagline: Arial45px, letterspacing3px; readable secondary brand line.
