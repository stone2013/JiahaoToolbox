import timeline from './timeline.json';
export const workbench={composition:'JiahaoPromo',fps:60,width:1920,height:1080,introSeconds:3,timeline};
