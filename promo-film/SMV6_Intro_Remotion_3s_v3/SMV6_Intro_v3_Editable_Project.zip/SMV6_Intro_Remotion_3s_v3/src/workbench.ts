// Editable timeline manifest. Values correspond to src/index.tsx.
export const workbench = {composition:'SMV6Intro',width:1920,height:1080,fps:60,durationInFrames:180,shots:[{id:'brand-lockup',from:0,duration:180,label:'SMV6 minimal studio ident'}],events:[{id:'wordmark',from:5,to:53},{id:'center-line',from:31,to:83},{id:'tagline',from:61,to:99},{id:'hold',from:99,to:180}]} as const;
