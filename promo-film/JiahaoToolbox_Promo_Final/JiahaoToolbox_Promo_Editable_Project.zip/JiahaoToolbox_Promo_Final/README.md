# 嘉豪工具箱 — 专业 Windows 系统工具与硬件监控

SMV6 正式产品宣传片制作工程。目标90秒、1920×1080、60FPS、16:9、H.264/AAC48kHz。当前软件为真实Windows11运行的v4.4.0 Beta；官方latest Release API在制作时返回404，片尾没有开放下载宣称。最终技术结果见TEST_REPORT.md。

## 文件
- JiahaoToolbox_Promo_Final_1080p60.mp4：带原创背景音乐及同步音效的主交付。
- JiahaoToolbox_Promo_SFX_Only_1080p60.mp4：相同画面、保留片头/音效的无BGM后期版。
- project/remotion：可编辑完整时间线、TSX、锁定依赖、相机组件、混音/导出/校验脚本。
- assets：原SMV6v3三秒片头、工具箱SVG Logo。
- audio：原创音乐、音效、钉帧表与来源说明。master*.wav为可重新生成的混音中间文件。
- recordings/raw-private：完整原始录屏的本地私有副本，含制作前个人字段，因此不进入公开ZIP或GitHub。
- project/remotion/public/media：原速、已遮挡私人信息的实际录屏片段；这是可公开编辑素材。
- storyboard.md：时间线与制作选择；reports：机器检查和独立审查证据。

## 编辑与重建
使用Node.js22+，Windows安装Microsoft YaHei/Segoe UI字体；FFmpeg/ffprobe7.1+，Python用于混音和验证（QA关键帧拼图另需Pillow）。

```powershell
cd project/remotion
npm ci --ignore-scripts
npm run dev
```

Studio选择JiahaoPromoFull预览完整90秒；JiahaoPromo是从3秒开始的87秒主段，成片脚本把原SMV6片头视频流直接拼接，避免重编码品牌设计。`bgm`输入属性控制是否预览背景音乐。src/timeline.json中的start是全片秒数，sourceIn对应public/media素材秒数；所有素材保持正常速度。src/index.tsx可修改标题、字幕、取景和缓动，src/workbench.ts提供编辑用清单。

```powershell
node scripts/synth-audio.mjs
python scripts/mix_audio.py
npm run typecheck
npm run render
python scripts/qa_final.py
```

FFMPEG_PATH、FFPROBE_PATH可设置工具绝对路径。REMOTION_BROWSER_EXECUTABLE可指定Chromium，未指定时导出会使用Remotion官方浏览器下载流程。源码包含所有视频编辑所需脱敏片段，无需访问私人完整原片。prepare_media.py仅用于本机原片追溯，需要原始录屏路径；常规修改与重建不运行该脚本。

## 音频与真实性
音乐与SFX为本项目原创程序化合成，源码和授权说明在audio/AUDIO_LICENSE.md；没有来源不明音乐。SFX为后期设计，不能作为软件原生提示声宣称。片头音效来自原已确认SMV6v3。响度双遍标准化、48kHz立体声、淡入淡出；机器结果不等于扬声器/耳机试听。

真实数据保持录制时状态；任务管理器展示实际进程页；第二个外部工具是已实现的Windows系统信息。设备名、账户、IP和进程名称使用不透明遮挡。未用静态截图模拟鼠标操作，未生成随机监控值。画面缩放最高1倍录屏像素，最终输出没有放大低清预览。

Kdenlive工程未提供：当前未验证其GUI加载与项目兼容性。可编辑工程以Remotion源码为准。此目录不会自动上传B站或创建GitHub Release。
