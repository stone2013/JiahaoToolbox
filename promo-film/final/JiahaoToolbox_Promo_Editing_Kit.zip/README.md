# 嘉豪工具箱真实操作宣传片

日期：2026-10-17。成片：final/JiahaoToolbox_Promo_1080p60.mp4，61 秒、1920×1080、60FPS，H.264/NVENC。

所有软件画面均来自真实运行的嘉豪工具箱 v4.4.0 和从工具箱打开的 Windows 任务管理器。没有模拟界面、随机监控数据、冻结或循环补时。片尾为品牌图形设计。SMV6 三秒片头使用用户提供的原始素材，保留其完整时长和声音；其余片段静音，未添加未授权配乐。

- 30 秒验收录像：media/reference/Recording_Test_30s_1080p60.mp4。
- 完整分镜和实际剪辑范围：STORYBOARD.md、reports/real-capture-provenance.json。
- 实录剪辑素材：media/capture/，原始 OBS 录像：raw/ 中 provenance 引用的四个文件。
- 可编辑工程：project/JiahaoToolbox_PROMO_EDITABLE.kdenlive，另有同名 MLT。画面、字幕、片头音频独立轨道。XML 和资源引用已验证，未安装并打开 Kdenlive 验收；工程沿用官方旧版 1.04 兼容格式，新版可能提示升级。FFmpeg 的淡入淡出以脚本为准，Kdenlive 草稿不保证逐帧复现导出转场。
- 字幕：subtitles/zh-CN.srt；可编辑 SVG 和透明 PNG：assets/captions/。
- 片尾：assets/outro.svg、outro.png；Logo 使用现有工程立方体。
- 测试范围及限制：RECORDING_TEST_REPORT.md。

## 重建

需要 Python 3.11 或以上版本、Pillow（requirements.txt）与可用的 FFmpeg/ffprobe。Windows 本机验证 FFmpeg 7.1.1 + RTX 3090 NVENC；FFmpeg 9.0.2 所需 NVENC API 高于本机驱动，故未使用它编码，也未修改驱动或安全设置。

```powershell
py -3 -m pip install -r requirements.txt
py -3 scripts/prepare_edit.py
py -3 scripts/render_promo.py --mode final --ffmpeg C:/path/ffmpeg.exe --ffprobe C:/path/ffprobe.exe
```

移动剪辑包后，先运行 prepare_edit.py 重建当前机器的媒体绝对路径。保留自己编辑后的 Kdenlive 工程副本，再重新生成。edit-manifest.json 保存各镜头路径、时长、哈希和验收状态；正式导出在验收证据或实录不完整、哈希不符时拒绝执行。脚本默认 NVENC；可显式使用 --encoder libx264。

scripts/build_real_segments.py 可按原始 OBS 时间码重建实录片段，需要 FFmpeg 和 ffprobe 在 PATH 中；不使用补帧、加速或冻结。scripts/package_editing_kit.py 仅打包剪辑材料，不打包 OBS 配置、鉴权信息、工具程序或个人设置。

旧文件 final/Jiahao_STORYBOARD_NOT_FINAL_1080p60.mp4 是录制前的待拍分镜预览，含明确黄色占位卡，不是正式宣传片，不在本次剪辑交付 ZIP 中。

本次没有上传任何录像或修改远程仓库。拍摄临时窗口尺寸已恢复到拍摄前保存的配置，SHA256 比对一致。
