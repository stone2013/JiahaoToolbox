from pathlib import Path
import subprocess,json,re,shutil,os,shutil as _shutil
R=Path(__file__).resolve().parents[4];P=R/'JiahaoToolbox_Promo_Final';FF=Path(os.environ.get('FFMPEG_PATH') or (str(R/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe') if (R/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe').exists() else (_shutil.which('ffmpeg') or 'ffmpeg')));A=P/'audio';W=P/'project/remotion/public/audio';W.mkdir(exist_ok=True)
bgm=A/'original-bgm-120bpm.wav';sfx=A/'original-sfx.wav'
base=[str(FF),'-hide_banner','-y','-i',str(bgm),'-i',str(sfx)]
filt='[0:a][1:a]amix=inputs=2:duration=longest:normalize=0'
run=subprocess.run(base+['-filter_complex',filt+',loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
m=json.loads(re.findall(r'\{\s*"input_i".*?\}',run.stderr,re.S)[-1]);(P/'reports/loudnorm-first-pass.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
ln='loudnorm=I=-16:TP=-1.5:LRA=8:measured_I={input_i}:measured_TP={input_tp}:measured_LRA={input_lra}:measured_thresh={input_thresh}:offset={target_offset}:linear=true:print_format=json'.format(**m)
master=A/'master-main.wav'
subprocess.run(base+['-filter_complex',filt+','+ln,'-ar','48000','-ac','2','-c:a','pcm_s16le',str(master)],capture_output=True,text=True,check=True)
shutil.copy2(master,W/'master-main.wav')
intro=P/'assets/SMV6_Intro_v3_1080p60.mp4'
subprocess.run([str(FF),'-v','error','-y','-i',str(intro),'-i',str(master),'-filter_complex','[0:a]atrim=duration=3,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a];[1:a]atrim=duration=87,asetpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=0:a=1','-ar','48000','-ac','2','-c:a','pcm_s16le',str(A/'master-full-90s.wav')],check=True)
subprocess.run([str(FF),'-v','error','-y','-i',str(intro),'-i',str(sfx),'-filter_complex','[0:a]atrim=duration=3,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a];[1:a]atrim=duration=87,asetpts=PTS-STARTPTS,volume=2[b];[a][b]concat=n=2:v=0:a=1','-ar','48000','-ac','2','-c:a','pcm_s16le',str(A/'sfx-only-full-90s.wav')],check=True)
subprocess.run([str(FF),'-v','error','-y','-i',str(sfx),'-af','volume=2','-ar','48000','-c:a','pcm_s16le',str(W/'master-sfx-only.wav')],check=True)
print('Two-pass normalized music+SFX master ready; original intro audio retained at0-3s.')
