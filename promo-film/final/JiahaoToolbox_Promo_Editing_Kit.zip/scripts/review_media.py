import argparse,hashlib,json,subprocess
from pathlib import Path
from render_promo import executable
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--ffmpeg');ap.add_argument('--ffprobe');args=ap.parse_args()
ff=args.ffmpeg or executable('ffmpeg');fp=args.ffprobe or executable('ffprobe')
reports=[]
for name,rel in [('preflight','media/reference/Preflight_REAL_NOT_APPROVED_FOR_PROMO.mp4'),('intro','media/intro/SMV6_Intro_v2_3s.mp4')]:
 p=ROOT/rel
 meta=json.loads(subprocess.check_output([str(fp),'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)],encoding='utf-8'))
 dec=subprocess.run([str(ff),'-hide_banner','-v','error','-i',str(p),'-f','null','-'],capture_output=True,text=True)
 black=subprocess.run([str(ff),'-hide_banner','-i',str(p),'-vf','blackdetect=d=0.05:pix_th=0.1:pic_th=0.98','-an','-f','null','-'],capture_output=True,text=True)
 audio=subprocess.run([str(ff),'-hide_banner','-i',str(p),'-af','volumedetect','-vn','-f','null','-'],capture_output=True,text=True)
 subprocess.run([str(ff),'-v','error','-y','-i',str(p),'-vf','fps=2,scale=480:270,tile=3x2','-frames:v','1',str(ROOT/f'reports/{name}-contact-sheet.png')],check=True)
 reports.append({'asset':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'probe':meta,'fullDecodeExitCode':dec.returncode,'decodeErrors':dec.stderr,'nearTotalBlackIntervals':[s for s in black.stderr.splitlines() if 'black_start' in s],'audioVolumeLog':[s for s in audio.stderr.splitlines() if 'mean_volume' in s or 'max_volume' in s],'limitations':'Black detection is a threshold check, not a semantic test. Preflight is static; 60fps metadata does not prove real animation smoothness.'})
(ROOT/'reports/media-review.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'asset':r['asset'],'duration':r['probe']['format']['duration'],'frames':r['probe']['streams'][0]['nb_read_frames'],'decodeOK':r['fullDecodeExitCode']==0,'blackIntervals':r['nearTotalBlackIntervals'],'audioVolume':r['audioVolumeLog']} for r in reports],ensure_ascii=False,indent=2))
