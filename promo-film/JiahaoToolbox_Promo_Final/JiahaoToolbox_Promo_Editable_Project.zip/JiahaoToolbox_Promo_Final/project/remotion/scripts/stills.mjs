import fs from 'node:fs';
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill,openBrowser} from '@remotion/renderer';
const root=process.cwd(),dir=path.resolve(root,'../../reports/stills');fs.mkdirSync(dir,{recursive:true});
const browserExe=process.env.REMOTION_BROWSER_EXECUTABLE||path.resolve(root,'../../../video-shotcraft-test/node_modules/.remotion/chrome-headless-shell/win64/chrome-headless-shell-win64/chrome-headless-shell.exe');
const serveUrl=await bundle({entryPoint:path.resolve('src/index.tsx')});
const browser=await openBrowser('chrome',{browserExecutable:browserExe});
try{
const comp=await selectComposition({serveUrl,id:'JiahaoPromo',puppeteerInstance:browser});
for(const frame of (process.argv.length>2?process.argv.slice(2).map(Number):[65,210,530,750,1040,1360,1640,1940,2260,2660,3080,3380,3610,3910,4330,4760,5050])){
 await renderStill({serveUrl,composition:comp,frame,output:path.join(dir,'f'+String(frame).padStart(4,'0')+'.png'),puppeteerInstance:browser});console.log('Still',frame);
}
}finally{await browser.close({silent:true});}
