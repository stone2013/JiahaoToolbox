import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));const root=path.resolve(here,'..');const dir=path.resolve(root,'../../audio');fs.mkdirSync(dir,{recursive:true});
const SR=48000,T=87,N=SR*T,TAU=Math.PI*2;
const music=new Float32Array(N),sfx=new Float32Array(N);
let seed=0x534d5636;function rnd(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296*2-1;}
const hz=m=>440*2**((m-69)/12);
function note(dst,start,dur,midi,amp,kind='pluck'){
 const freq=hz(midi),len=Math.min(Math.round(dur*SR),N-Math.round(start*SR)),pos=Math.round(start*SR);
 for(let i=0;i<len;i++){let t=i/SR,x=t/dur,env=(1-Math.exp(-t/(kind==='pad'?.12:.012)))*Math.min(1,(dur-t)/.12);let v;
  if(kind==='pad'){env*=Math.sin(Math.PI*x)**.55;v=(Math.sin(TAU*freq*t)+.30*Math.sin(TAU*freq*1.002*t)+.13*Math.sin(TAU*2*freq*t))/1.43;}
  else if(kind==='bass'){env*=Math.exp(-t*3);v=Math.sin(TAU*freq*t)+.12*Math.sin(TAU*2*freq*t);}
  else{env*=Math.exp(-t*4);v=Math.sin(TAU*freq*t+.32*Math.sin(TAU*2*freq*t)*Math.exp(-t*5))+.12*Math.sin(TAU*3*freq*t);}
  dst[pos+i]+=v*env*amp;
 }
}
function drum(start,kind,amp){let dur=kind==='kick'?.26:kind==='snare'?.15:.055,pos=Math.round(start*SR),lp=0;
 for(let i=0;i<dur*SR&&pos+i<N;i++){let t=i/SR,n=rnd();lp=.82*lp+.18*n;let v;
 if(kind==='kick')v=Math.sin(TAU*(48*t+55*.020*(1-Math.exp(-t/.020))))*Math.exp(-t*22);
 else if(kind==='snare')v=(n-lp)*Math.exp(-t*32)*.65+Math.sin(TAU*185*t)*Math.exp(-t*35)*.18;
 else v=(n-lp)*Math.exp(-t*95)*.28;
 music[pos+i]+=amp*v*(1-Math.exp(-t/.0015));}
}
const chords=[[52,59,62,66],[48,55,59,64],[43,50,54,59],[50,57,62,64]];
// Original 120BPM composition; no external samples. One bar=2sec, half-beat=.25sec.
for(let bar=0;bar<44;bar++){
 const st=bar*2,ch=chords[Math.floor(bar/4)%4],intense=st>20&&st<78?1:.8;
 for(const n of ch)note(music,st,2.1,n,.030,'pad');
 for(let beat=0;beat<4;beat++){
  let t=st+beat*.5;if(t>=82)continue;
  note(music,t,.42,ch[0]-12,.12*intense,'bass');drum(t,'kick',.22*intense);
  if(beat===1||beat===3)drum(t,'snare',.11*intense);
  drum(t,'hat',.085);drum(t+.25,'hat',.045);
 }
 for(let a=0;a<8;a++){
  const pattern=[0,2,1,3,2,1,3,2];let n=ch[pattern[a]]+12;
  if(st<82)note(music,st+a*.25,.82,n,.052*intense,'pluck');
 }
}
for(const n of [52,59,64,66,71])note(music,82,4.8,n,.04,'pad');
const timeline=JSON.parse(fs.readFileSync(path.join(root,'src/timeline.json'),'utf8'));
const events=[];
function whoosh(t,amp=.10,dur=.32){let pos=Math.round(t*SR),low=0;
 for(let i=0;i<dur*SR&&pos+i<N;i++){let x=i/(dur*SR),noise=rnd();low=.9*low+.1*noise;let env=Math.sin(Math.PI*x)**2; sfx[pos+i]+=low*env*amp*3;}
}
function tick(t,amp=.12){let pos=Math.round(t*SR),low=0;for(let i=0;i<.06*SR&&pos+i<N;i++){let x=i/SR,n=rnd();low=.6*low+.4*n;sfx[pos+i]+=(low*.7+Math.sin(TAU*780*x)*.12)*Math.exp(-x*85)*amp*(1-Math.exp(-x/.001));}}
for(const s of timeline){
 const t=s.start-3;whoosh(Math.max(0,t-.09),s.view==='hero'||s.view==='outro'?.18:.11);events.push({frame:Math.round(t*60),globalSeconds:s.start,kind:'original soft whoosh',purpose:s.title});
 if(s.start===3||s.start===12||s.start===46||s.start===85){note(sfx,t+.15,1.2,76,.10,'pluck');note(sfx,t+.15,1.5,83,.05,'pluck');events.push({frame:Math.round((t+.15)*60),kind:'original text reveal accent'});}
}
for(const t of [45+49/60,47+44/60,50+31/60,53+43/60,60+38/60]){tick(t,.32);events.push({frame:Math.round(t*60),kind:'original soft click foley',note:'Editorial SFX, not recorded operating-system audio'});}
for(const n of [64,71,76])note(sfx,82.5,3.9,n,.085,'pad');
function writeWav(file,a,stereo=true){let channels=stereo?2:1;const b=Buffer.alloc(44+a.length*2*channels);b.write('RIFF');b.writeUInt32LE(b.length-8,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(channels,22);b.writeUInt32LE(SR,24);b.writeUInt32LE(SR*channels*2,28);b.writeUInt16LE(channels*2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(a.length*channels*2,40);
 for(let i=0;i<a.length;i++){let t=i/SR,fade=Math.min(1,t/.6,Math.max(0,(T-t)/2.6));let v=a[i]*fade;let l=Math.max(-1,Math.min(1,v)),rr=Math.max(-1,Math.min(1,v*.96+(i>360?a[i-360]*.04:0)*fade));b.writeInt16LE(Math.round(l*32767),44+i*channels*2);if(stereo)b.writeInt16LE(Math.round(rr*32767),46+i*channels*2);}
 fs.writeFileSync(file,b);
}
writeWav(path.join(dir,'original-bgm-120bpm.wav'),music);writeWav(path.join(dir,'original-sfx.wav'),sfx);
fs.writeFileSync(path.join(dir,'SFX_CUES.json'),JSON.stringify(events,null,2));
fs.writeFileSync(path.join(dir,'AUDIO_LICENSE.md'),'# Original audio provenance\n\nBackground music and SFX are original deterministic procedural compositions created for this Jiahao Toolbox film. No third-party music, samples, sound libraries or recordings were used. Synthesis source is project/remotion/scripts/synth-audio.mjs. The user may use, modify and distribute these generated audio assets with the film. SMV6 intro audio is the original user-approved v3 asset.\n\n120 BPM, E minor, 48kHz stereo PCM. BGM fades in0.6s and out2.6s. Editorial SFX are postproduction sound design, not claims of native software UI sounds.\n');
console.log('Original BGM and SFX rendered: 87s, 48kHz stereo; cue table saved.');

