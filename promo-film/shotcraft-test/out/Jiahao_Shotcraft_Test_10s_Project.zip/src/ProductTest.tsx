import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, OffthreadVideo, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {PageCam, type CamKey} from './lib/PageCam';

export const TOKENS={bg:'#081321',surface:'#102037',text:'#f2f6ff',muted:'#a6b5cb',accent:'#168bff',line:'#26374e'};
const font="'Segoe UI Variable','Segoe UI','Microsoft YaHei UI','Microsoft YaHei',sans-serif";
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const ease=Easing.bezier(0.22,1,0.36,1);
export const CAMERA: CamKey[]=[
  {frame:0,cx:960,cy:535,zoom:0.64,rotY:-12,rotX:2,persp:5000},
  {frame:36,cx:960,cy:535,zoom:0.65,rotY:-10,rotX:1.5,persp:5000},
  {frame:180,cx:960,cy:535,zoom:0.70,rotY:0,rotX:0,persp:5000},
  {frame:300,cx:960,cy:535,zoom:0.70,rotY:0,rotX:0,persp:5000},
];

export const Intro: React.FC=()=> <AbsoluteFill style={{background:'#090c10'}}><OffthreadVideo src={staticFile('SMV6_Intro_v2_3s.mp4')} style={{width:1920,height:1080}}/></AbsoluteFill>;

export const Hero: React.FC<{title?:string}>=({title='真实界面，清晰呈现'})=>{
  const f=useCurrentFrame();
  const arrival=interpolate(f,[0,40],[0,1],{...clamp,easing:ease});
  const leave=interpolate(f,[286,300],[1,0],clamp);
  const note=interpolate(f,[44,82],[0,1],{...clamp,easing:ease});
  return <AbsoluteFill style={{background:TOKENS.bg,fontFamily:font,color:TOKENS.text}}>
    <AbsoluteFill style={{background:'radial-gradient(ellipse at 41% 50%, #143c65 0%, #0b1b2d 44%, #081321 72%)'}}/>
    <div style={{position:'absolute',left:72,top:68,zIndex:3,display:'flex',alignItems:'center',gap:24,opacity:arrival*leave}}>
      <Img src={staticFile('logo.svg')} style={{width:64,height:70}}/>
      <span style={{fontSize:60,fontWeight:700,letterSpacing:1}}>嘉豪工具箱</span>
      <span style={{fontSize:34,color:TOKENS.muted,marginLeft:8}}>v4.4.0</span>
    </div>
    <div style={{position:'absolute',inset:0,transform:`translate(-160px,${28*(1-arrival)}px)`,opacity:arrival*leave}}>
      <PageCam src="textures/cpu-real.png" pageH={1080} keys={CAMERA} ease={Easing.bezier(0.35,0,0.2,1)}>
        <div style={{position:'absolute',inset:0,border:`1px solid ${TOKENS.line}`,borderRadius:12,pointerEvents:'none'}}/>
      </PageCam>
    </div>
    <div style={{position:'absolute',left:1500,top:354,width:348,opacity:note*leave,transform:`translateY(${18*(1-note)}px)`}}>
      <div style={{height:4,width:64,background:TOKENS.accent,marginBottom:35}}/>
      <div style={{fontSize:70,fontWeight:700,lineHeight:1.24,letterSpacing:1}}>CPU 监控</div>
      <div style={{fontSize:58,fontWeight:600,lineHeight:1.45,marginTop:34}}>{title.split('，').map((t,i)=><React.Fragment key={t}>{i>0&&<br/>}{t}</React.Fragment>)}</div>
      <div style={{fontSize:34,color:TOKENS.muted,lineHeight:1.6,marginTop:34}}>真实界面快照<br/>非实时采样演示</div>
    </div>
    <div style={{position:'absolute',left:82,bottom:54,right:72,display:'flex',justifyContent:'space-between',fontSize:34,color:TOKENS.muted,opacity:arrival*leave}}>
      <span>原生 1920 × 1080 · 60 FPS</span>
      <span>10 秒动效测试 / Remotion</span>
    </div>
  </AbsoluteFill>;
};

export const Brand:React.FC<{tagline?:string}>=({tagline='让常用功能触手可及'})=>{
 const f=useCurrentFrame();const a=interpolate(f,[0,24],[0,1],{...clamp,easing:ease});
 return <AbsoluteFill style={{background:TOKENS.bg,color:TOKENS.text,fontFamily:font,alignItems:'center',justifyContent:'center'}}>
   <div style={{display:'flex',gap:48,alignItems:'center',opacity:a,transform:`translateY(${20*(1-a)}px)`}}>
     <Img src={staticFile('logo.svg')} style={{width:142,height:156}}/>
     <div><div style={{fontSize:100,fontWeight:700,letterSpacing:3}}>嘉豪工具箱</div><div style={{fontSize:38,color:'#83c8ff',letterSpacing:6,marginTop:12}}>JIAHAO TOOLBOX</div></div>
   </div>
   <div style={{position:'absolute',top:724,fontSize:58,color:TOKENS.muted,opacity:a}}>{tagline}</div>
 </AbsoluteFill>;
};

export const SHOTS=[{id:'intro',from:0,duration:180,component:Intro},{id:'hero',from:180,duration:300,component:Hero},{id:'brand',from:480,duration:120,component:Brand}];
export const ProductTest:React.FC=()=> <AbsoluteFill style={{background:TOKENS.bg}}>{SHOTS.map(s=><Sequence key={s.id} from={s.from} durationInFrames={s.duration}><s.component/></Sequence>)}</AbsoluteFill>;
