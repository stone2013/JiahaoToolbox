# Original audio provenance

Background music and SFX are original deterministic procedural compositions created for this Jiahao Toolbox film. No third-party music, samples, sound libraries or recordings were used. Synthesis source is project/remotion/scripts/synth-audio.mjs. The user may use, modify and distribute these generated audio assets with the film. SMV6 intro audio is the original user-approved v3 asset.

120 BPM, E minor, 48kHz stereo PCM. BGM fades in0.6s and out2.6s. Editorial SFX are postproduction sound design, not claims of native software UI sounds.
