# 嘉豪工具箱 · video-shotcraft 10 秒验证

已在当前 Windows 环境安装 Skill，并实际使用其中的 PageCam 组件完成 Remotion 渲染测试。本工程仅为安装与质量验证，不是完整宣传片。

## 文件

- `out/Jiahao_Shotcraft_Test_10s_1080p60.mp4`：最终测试片。
- `src/`：完整 React/TypeScript/Remotion 工程，包含可编辑文案及同源 `workbench.ts` 清单。
- `public/`：原始 SMV6 三秒片头、实际 CPU 页面截图和工程原有 SVG Logo。
- `out/ffprobe.json`：ffprobe 原始报告。
- `out/TEST_REPORT.json`：分辨率、帧率、600 帧、10 秒、解码和截图不放大约束验证。
- `review/INSTALL_AUDIT.json`：来源、固定提交、1359 个文件一致性、依赖下载域名、跳过安装钩子等审计记录。
- `DESIGN_SPEC.md`：素材来源、镜头与需求对应及产品视觉 tokens。

画面结构：0–3 秒 SMV6；3–8 秒真实 CPU 截图运镜；8–10 秒品牌。截图标注“真实界面快照 / 非实时采样演示”，不改动监控数字或曲线；没有模拟鼠标操作。原生画布 1920×1080、60FPS、scale=1；截图在片中缩小展示，保守透视像素倍率低于原始窗口像素。视频流直接保留 Remotion 的 600 帧，FFmpeg 只处理音轨尾部，使容器时长精确 10.000 秒。

## 安装记录

仓库：[Vincentwei1021/video-shotcraft](https://github.com/Vincentwei1021/video-shotcraft)，固定提交 `310330cadcf41f5d2b15ee1c908d629e26d0a324`。

安装位置：`C:/Users/stone/.codex/skills/video-shotcraft`。使用 Codex 自带 skill-installer 下载固定提交到官方 README 支持的 Codex Skills 目录布局，不运行远程 shell 或 `npx skills` 安装器。README、SKILL.md、依赖和脚本清单已读取。对照 GitHub Git tree 校验了 1359 个仓库文件；项目依赖使用官方模板锁定的 Remotion 4.0.484、React 19.2.7，通过 `npm ci --ignore-scripts` 安装，不执行依赖安装钩子。无头 Chrome 由 Remotion 官方 `browser ensure` 命令从 Google Chrome for Testing 下载。

Skill 文件名及 YAML frontmatter 校验通过，本轮已直接读取并实际复用安装后的能力。新建的独立审查上下文已在 available skills 列表中识别到 video-shotcraft:video-shotcraft。当前对话的固定技能列表将在下一轮刷新；后续可直接输入“使用 video-shotcraft”。自动触发的所有提示语未逐一测试。

## 重建和编辑

Node.js v24.19.0、npm 11.17.0；本机 FFmpeg/ffprobe 7.1.1 可用。Remotion 是项目本地依赖，未安装为全局 npm 包。FFmpeg 当前使用已有工程内的可信工具路径；其他机器请把它们加入 PATH，或设置下列变量，不需要更改系统设置。

```powershell
npm ci --ignore-scripts --no-audit --no-fund
npx --no-install remotion browser ensure
$env:FFMPEG_PATH = 'C:/path/to/ffmpeg.exe'
$env:FFPROBE_PATH = 'C:/path/to/ffprobe.exe'
npm run typecheck
npm run render
npm run qa
npm run dev
```

Remotion Studio 可以编辑/预览全部源码。本次未启动可选 Motion Workbench 常驻服务或 Windows GUI；其清单已保留，但未验证工作台导入与导出。工程 ZIP 不包含 node_modules 与下载的浏览器，锁文件和素材完整保留。

## 授权与范围

PageCam 源于 video-shotcraft，Apache-2.0 许可见 `SHOTCRAFT_LICENSE`；本地修改是外层背景透明化。Remotion 使用其[独立许可](https://github.com/remotion-dev/remotion/blob/main/LICENSE.md)。用户提供的 SMV6 片头和嘉豪工具箱素材沿用原授权，本测试没有上传或发布。

没有新增 BGM、音效或配音，只保留原片头音轨；没有进行音箱听音验收。不将本测试当作完整功能实录或 Windows 软件回归测试。
