from pathlib import Path
import subprocess,json,re,array,math,hashlib,sys,os,shutil
P=Path(__file__).resolve().parents[3];ROOT=P.parent;tools=ROOT/'promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin';FF=Path(os.environ.get('FFMPEG_PATH') or (str(tools/'ffmpeg.exe') if (tools/'ffmpeg.exe').exists() else (shutil.which('ffmpeg') or 'ffmpeg')));FP=Path(os.environ.get('FFPROBE_PATH') or (str(tools/'ffprobe.exe') if (tools/'ffprobe.exe').exists() else (shutil.which('ffprobe') or 'ffprobe')));V=P/'JiahaoToolbox_Promo_Final_1080p60.mp4';R=P/'reports';R.mkdir(exist_ok=True)
def run(args):return subprocess.run([str(FF),*args],capture_output=True,check=True)
j=json.loads(subprocess.check_output([str(FP),'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(V)]));j['format']['filename']=V.name;(R/'ffprobe-final.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
v=next(s for s in j['streams'] if s['codec_type']=='video');a=next(s for s in j['streams'] if s['codec_type']=='audio')
assert(v['width'],v['height'],v['avg_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'60/1',5400)
assert v['codec_name']=='h264';assert a['codec_name']=='aac' and a['sample_rate']=='48000';assert abs(float(j['format']['duration'])-90)<.02
x=run(['-v','error','-i',str(V),'-f','null','-']);assert not x.stderr.strip(),x.stderr.decode(errors='replace')
# Pixel-identical original brand intro: compare decoded frames, independent of MP4 metadata.
def hashes(f,limit=None):
 args=['-v','error','-i',str(f),'-map','0:v:0','-an'];
 if limit:args+=['-frames:v',str(limit)]
 out=run(args+['-f','framemd5','-']).stdout.decode();return [ln.split(',')[-1].strip() for ln in out.splitlines() if ln and not ln.startswith('#')]
intro=hashes(P/'assets/SMV6_Intro_v3_1080p60.mp4');got=hashes(V,180);assert intro==got and len(got)==180
black=run(['-hide_banner','-i',str(V),'-vf','blackdetect=d=0.05:pix_th=0.01:pic_th=0.9999','-an','-f','null','-']).stderr.decode(errors='replace');bl=[x for x in black.splitlines() if 'black_start:' in x];(R/'blackdetect.txt').write_text(black.replace(str(ROOT),'<workspace>'),encoding='utf-8')
sil=run(['-hide_banner','-i',str(V),'-af','silencedetect=noise=-55dB:d=0.4','-vn','-f','null','-']).stderr.decode(errors='replace');sl=[x for x in sil.splitlines() if 'silence_' in x];(R/'silencedetect.txt').write_text(sil.replace(str(ROOT),'<workspace>'),encoding='utf-8')
loud=run(['-hide_banner','-i',str(V),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-vn','-f','null','-']).stderr.decode(errors='replace');lm=json.loads(re.findall(r'\{\s*"input_i".*?\}',loud,re.S)[-1]);(R/'loudness-final.json').write_text(json.dumps(lm,indent=2),encoding='utf-8')
assert float(lm['input_tp'])<-.3
samples=array.array('f');samples.frombytes(run(['-v','error','-i',str(V),'-map','0:a:0','-ac','1','-ar','48000','-f','f32le','-']).stdout)
rms=[]
for sec in range(90):
 seg=samples[sec*48000:(sec+1)*48000];r=math.sqrt(sum(float(x)**2 for x in seg)/max(1,len(seg)));rms.append(round(20*math.log10(max(1e-12,r)),2))
assert all(x>-40 for x in rms[4:88]),rms
(R/'audio-rms-1s.json').write_text(json.dumps(rms,indent=2),encoding='utf-8')
# Honest scope: liveness check on the 36-46s live-display demonstration, not a global FPS benchmark.
x=run(['-v','error','-ss','36','-t','10','-i',str(V),'-an','-f','framemd5','-']).stdout.decode();live=[ln.split(',')[-1].strip() for ln in x.splitlines() if ln and not ln.startswith('#')]
encodedHash=lambda f:run(['-v','error','-i',str(f),'-map','0:v:0','-c:v','copy','-f','hash','-hash','sha256','-']).stdout.decode().strip()
assert encodedHash(V)==encodedHash(P/'JiahaoToolbox_Promo_SFX_Only_1080p60.mp4')
report={'sfxOnlyVideoBitstreamIdentical':True,'file':V.name,'sha256':hashlib.sha256(V.read_bytes()).hexdigest(),'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'frames':int(v['nb_read_frames']),'duration':v['duration']},'audio':{'codec':a['codec_name'],'sampleRate':a['sample_rate'],'channels':a['channels'],'duration':a['duration'],'integratedLUFS':lm['input_i'],'truePeakDBTP':lm['input_tp'],'minRmsDBFSFrom4To88s':min(rms[4:88]),'longSilenceEvents':sl},'fullDecode':'passed without errors','originalIntro180DecodedFramesIdentical':True,'pureBlackEvents':bl,'liveDisplay10s':{'frames':len(live),'uniqueHashes':len(set(live)),'scope':'Output movement check only; camera motion also changes pixels. Not a UI or hardware FPS benchmark.'},'avStartDifferenceSeconds':abs(float(v.get('start_time',0))-float(a.get('start_time',0))),'avDurationDifferenceSeconds':abs(float(v['duration'])-float(a['duration']))}
assert report['avDurationDifferenceSeconds']<.04
(R/'qa-final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=True,indent=2))
