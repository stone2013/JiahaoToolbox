import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=process.cwd(),out=path.resolve(root,'../..');
const browser=process.env.REMOTION_BROWSER_EXECUTABLE||path.resolve(root,'../../../video-shotcraft-test/node_modules/.remotion/chrome-headless-shell/win64/chrome-headless-shell-win64/chrome-headless-shell.exe');
let args=[path.join(root,'node_modules/@remotion/cli/remotion-cli.js'),'render','src/index.tsx','JiahaoPromo',path.join(out,'reports/remotion-main-87s.mp4'),'--log=info','--image-format=jpeg','--jpeg-quality=97','--concurrency=6'];
if(fs.existsSync(browser))args.push('--browser-executable='+browser);
if(!process.argv.includes('--finish-only'))execFileSync(process.execPath,args,{cwd:root,stdio:'inherit'});
const fallback=path.resolve(root,'../../../promo-film/tools/ffmpeg-compatible/ffmpeg-7.1.1-essentials_build/bin/ffmpeg.exe');
const ff=process.env.FFMPEG_PATH||(fs.existsSync(fallback)?fallback:'ffmpeg');
// JPEG-rendered H.264 can be full-range. Normalize the main segment only;
// never re-encode the approved three-second brand intro.
const fp=process.env.FFPROBE_PATH||ff.replace(/ffmpeg(\.exe)?$/,'ffprobe$1');
const main=path.join(out,'reports/remotion-main-87s.mp4');
const probe=JSON.parse(execFileSync(fp,['-v','error','-select_streams','v:0','-show_streams','-of','json',main],{encoding:'utf8'})).streams[0];
if(probe.color_range==='pc'||probe.pix_fmt==='yuvj420p'){
 const normalized=path.join(out,'reports/main-normalized.mp4');
 execFileSync(ff,['-v','error','-y','-i',main,'-an','-vf','scale=in_range=pc:out_range=tv,setsar=1,format=yuv420p','-c:v','libx264','-preset','medium','-crf','16','-bf','2','-color_range','tv','-r','60','-fps_mode','cfr','-enc_time_base','1/60','-video_track_timescale','60000',normalized],{stdio:'inherit'});
 fs.renameSync(normalized,main);
}
for(const [src,dst] of [[path.join(out,'assets/SMV6_Intro_v3_1080p60.mp4'),'intro-remux.mp4'],[path.join(out,'reports/remotion-main-87s.mp4'),'main-remux.mp4']])execFileSync(ff,['-v','error','-y','-i',src,'-map','0:v:0','-an','-c:v','copy','-video_track_timescale','60000',path.join(out,'reports',dst)],{stdio:'inherit'});
const list=path.join(out,'reports/concat.txt');fs.writeFileSync(list,"file 'intro-remux.mp4'\nfile 'main-remux.mp4'\n");
// Assemble full audio from the editable preview masters. No Python is needed for a normal re-render.
fs.mkdirSync(path.join(out,'audio'),{recursive:true});
for(const [stem,name] of [['master-main.wav','master-full-90s.wav'],['master-sfx-only.wav','sfx-only-full-90s.wav']])execFileSync(ff,['-v','error','-y','-i',path.join(out,'assets/SMV6_Intro_v3_1080p60.mp4'),'-i',path.join(root,'public/audio',stem),'-filter_complex','[0:a]atrim=duration=3,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a];[1:a]atrim=duration=87,asetpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=0:a=1','-ar','48000','-ac','2','-c:a','pcm_s16le',path.join(out,'audio',name)],{stdio:'inherit'});
for(const [audio,name] of [['master-full-90s.wav','JiahaoToolbox_Promo_Final_1080p60.mp4'],['sfx-only-full-90s.wav','JiahaoToolbox_Promo_SFX_Only_1080p60.mp4']])execFileSync(ff,['-v','error','-y','-f','concat','-safe','0','-i',list,'-i',path.join(out,'audio',audio),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-ac','2','-t','90','-video_track_timescale','60000','-movflags','+faststart','-metadata','title=嘉豪工具箱 — 专业 Windows 系统工具与硬件监控','-metadata','artist=SMV6',path.join(out,name)],{stdio:'inherit'});
console.log('Primary and SFX-only 90s MP4s assembled; original intro video stream preserved.');
